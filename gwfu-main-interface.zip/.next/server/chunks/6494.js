"use strict";
exports.id = 6494;
exports.ids = [6494];
exports.modules = {

/***/ 6494:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TokenList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var _ColoredNumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4593);
/* harmony import */ var _components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7271);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5780);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6269);










function TokenListName({
  token
}) {
  const currency = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useCurrency */ .U8)(token.address);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "flex items-center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        currency: currency,
        size: 32
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "ml-3 font-bold text-high-emphesis",
        children: token.symbol
      })]
    })
  });
}

function TokenList({
  tokens
}) {
  const columns = react__WEBPACK_IMPORTED_MODULE_4___default().useMemo(() => [{
    Header: 'Name',
    accessor: 'token',
    Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TokenListName, {
      token: props.value
    }),
    disableSortBy: true,
    align: 'left'
  }, {
    Header: 'Liquidity',
    accessor: 'liquidity',
    Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .formatNumberScale */ .nH)(props.value, true),
    align: 'right'
  }, {
    Header: 'Volume (24h)',
    accessor: 'volume24h',
    Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(props.value, true),
    align: 'right'
  }, {
    Header: 'Price',
    accessor: 'price',
    Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(props.value, true),
    align: 'right'
  }, {
    Header: '24h',
    accessor: 'change1d',
    Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ColoredNumber__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      number: props.value,
      percent: true
    }),
    align: 'right'
  }, {
    Header: '7d',
    accessor: 'change1w',
    Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ColoredNumber__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      number: props.value,
      percent: true
    }),
    align: 'right'
  }], []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: tokens && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      columns: columns,
      data: tokens,
      defaultSortBy: {
        id: 'liquidity',
        desc: true
      },
      link: {
        href: '/analytics/tokens/',
        id: 'token.address'
      }
    })
  });
}

/***/ })

};
;