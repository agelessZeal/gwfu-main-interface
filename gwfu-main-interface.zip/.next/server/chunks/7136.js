"use strict";
exports.id = 7136;
exports.ids = [7136];
exports.modules = {

/***/ 8561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dots)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3289);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);





function Dots({
  children = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
  className
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
      id: "106137454",
      children: [".dots.jsx-106137454::after{content:'.';}"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
      className: "jsx-106137454" + " " + ((0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)('after:inline-block dots after:animate-ellipsis after:w-4 after:text-left', className) || ""),
      children: children
    })]
  });
}

/***/ }),

/***/ 4509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var hooks = __webpack_require__(4663);
;// CONCATENATED MODULE: ./src/components/Polling.tsx







function Polling() {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const blockNumber = (0,hooks/* useBlockNumber */.Ov)();
  const {
    0: isMounted,
    1: setIsMounted
  } = (0,external_react_.useState)(true);
  (0,external_react_.useEffect)(() => {
    const timer1 = setTimeout(() => setIsMounted(true), 1000); // this will clear Timeout when component unmount like in willComponentUnmount

    return () => {
      setIsMounted(false);
      clearTimeout(timer1);
    };
  }, [blockNumber] // useEffect will run only one time
  // if you pass a value to array, like this [data] than clearTimeout will run every time this value changes (useEffect re-run)
  );
  return /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
    href: chainId && blockNumber ? (0,explorer/* getExplorerLink */.E)(chainId, blockNumber.toString(), 'block') : '',
    className: `${!isMounted ? 'text-high-emphesis' : 'text-low-emphesis'}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `flex items-center space-x-2`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        children: blockNumber
      }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: `h-6 w-6 ${!isMounted ? 'animate-spin' : ''}`,
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        children: /*#__PURE__*/jsx_runtime_.jsx("path", {
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2",
          d: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
        })
      })]
    })
  });
}
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/Footer/index.tsx









const Footer = () => {
  const {
    chainId
  } = (0,useActiveWeb3React/* default */.Z)();
  const {
    i18n
  } = (0,react_.useLingui)();
  return (
    /*#__PURE__*/
    // <footer className="absolute bottom-0 flex items-center justify-between w-screen h-20 p-4 mx-auto text-center text-low-emphesis">
    jsx_runtime_.jsx("footer", {
      className: "flex-shrink-0 w-full",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between h-20 px-4",
        children: [chainId && chainId in constants/* ANALYTICS_URL */.fi && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `analytics-nav-link`,
          href: constants/* ANALYTICS_URL */.fi[chainId] || 'https://analytics.sushi.com',
          className: "text-low-emphesis",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center space-x-2",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              children: i18n._(
              /*i18n*/
              i18n._("Analytics"))
            }), /*#__PURE__*/jsx_runtime_.jsx("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              className: "w-6 h-6",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
              })
            })]
          })
        }), chainId && chainId === sdk_.ChainId.MATIC && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `polygon-bridge-link`,
          href: "https://wallet.matic.network/bridge/",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Matic Bridge"))
        }), chainId && chainId === sdk_.ChainId.HARMONY && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `harmony-bridge-link`,
          href: " https://bridge.harmony.one/tokens",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Harmony Bridge"))
        }), chainId && chainId === sdk_.ChainId.XDAI && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `xdai-bridge-link`,
          href: " https://omni.xdaichain.com/",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("xDai Bridge"))
        }), chainId && chainId === sdk_.ChainId.PALM && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
          id: `palm-bridge-link`,
          href: " https://app.palm.io/bridge",
          className: "text-low-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Palm Bridge"))
        }), /*#__PURE__*/jsx_runtime_.jsx(Polling, {})]
      })
    })
  );
};

/* harmony default export */ const components_Footer = (Footer);

/***/ }),

/***/ 8229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/functions/feature.ts
var feature = __webpack_require__(1986);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(9260);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/NavLink/index.tsx
var NavLink = __webpack_require__(3233);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(4025);
// EXTERNAL MODULE: ./src/constants/networks.ts
var networks = __webpack_require__(4965);
// EXTERNAL MODULE: ./src/modals/NetworkModal/index.tsx
var NetworkModal = __webpack_require__(8828);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var hooks = __webpack_require__(4663);
;// CONCATENATED MODULE: ./src/components/Web3Network/index.tsx









function Web3Network() {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const toggleNetworkModal = (0,hooks/* useNetworkModalToggle */.o)();
  if (!chainId) return null;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex items-center rounded bg-middle-green hover:bg-green p-0.5 whitespace-nowrap text-sm font-bold cursor-pointer select-none pointer-events-auto" // onClick={() => toggleNetworkModal()}
    ,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid items-center grid-flow-col px-3 py-2 space-x-2 text-sm rounded-lg pointer-events-auto auto-cols-max bg-green text-secondary",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: networks/* NETWORK_ICON */.w[chainId],
        alt: "Switch Network",
        className: "rounded-md",
        width: "22px",
        height: "22px"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-white",
        children: networks/* NETWORK_LABEL */.z[chainId]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(NetworkModal/* default */.Z, {})]
  });
}

/* harmony default export */ const components_Web3Network = (Web3Network);
// EXTERNAL MODULE: ./src/connectors/index.ts + 1 modules
var connectors = __webpack_require__(1378);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var transactions_hooks = __webpack_require__(9123);
// EXTERNAL MODULE: ./src/components/Loader/index.tsx
var Loader = __webpack_require__(4419);
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(417);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
// EXTERNAL MODULE: external "copy-to-clipboard"
var external_copy_to_clipboard_ = __webpack_require__(8929);
var external_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_copy_to_clipboard_);
;// CONCATENATED MODULE: ./src/hooks/useCopyClipboard.ts


function useCopyClipboard(timeout = 500) {
  const {
    0: isCopied,
    1: setIsCopied
  } = (0,external_react_.useState)(false);
  const staticCopy = (0,external_react_.useCallback)(text => {
    const didCopy = external_copy_to_clipboard_default()(text);
    setIsCopied(didCopy);
  }, []);
  (0,external_react_.useEffect)(() => {
    if (isCopied) {
      const hide = setTimeout(() => {
        setIsCopied(false);
      }, timeout);
      return () => {
        clearTimeout(hide);
      };
    }

    return undefined;
  }, [isCopied, setIsCopied, timeout]);
  return [isCopied, staticCopy];
}
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: ./src/components/Typography/index.tsx
var Typography = __webpack_require__(3130);
// EXTERNAL MODULE: external "@lingui/react"
var external_lingui_react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/AccountDetails/Copy.tsx










const CopyHelper = ({
  className,
  toCopy,
  children
}) => {
  const [isCopied, setCopied] = useCopyClipboard();
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (0,functions/* classNames */.AK)('flex items-center flex-shrink-0 space-x-1 no-underline cursor-pointer whitespace-nowrap hover:no-underline focus:no-underline active:no-underline text-blue opacity-80 hover:opacity-100 focus:opacity-100', className),
    onClick: () => setCopied(toCopy),
    children: [isCopied && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex items-center space-x-1 whitespace-nowrap",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
        variant: "sm",
        children: i18n._(
        /*i18n*/
        i18n._("Copied"))
      }), /*#__PURE__*/jsx_runtime_.jsx(esm/* CheckCircleIcon */.rE2, {
        width: 16,
        height: 16
      })]
    }), !isCopied && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [children, /*#__PURE__*/jsx_runtime_.jsx(esm/* ClipboardCopyIcon */.dqY, {
        width: 16,
        height: 16
      })]
    })]
  });
};

/* harmony default export */ const Copy = (CopyHelper);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9337);
// EXTERNAL MODULE: ./src/components/ModalHeader/index.tsx
var ModalHeader = __webpack_require__(7144);
// EXTERNAL MODULE: ./src/state/transactions/actions.ts
var actions = __webpack_require__(7219);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
;// CONCATENATED MODULE: ./src/components/AccountDetails/Transaction.tsx


















const calculateSecondsUntilDeadline = tx => {
  var _tx$archer;

  if (tx !== null && tx !== void 0 && (_tx$archer = tx.archer) !== null && _tx$archer !== void 0 && _tx$archer.deadline && tx !== null && tx !== void 0 && tx.addedTime) {
    const millisecondsUntilUntilDeadline = tx.archer.deadline * 1000 - Date.now();
    return millisecondsUntilUntilDeadline < 0 ? -1 : Math.ceil(millisecondsUntilUntilDeadline / 1000);
  }

  return -1;
};

const Transaction = ({
  hash
}) => {
  var _tx$receipt, _tx$receipt2;

  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const allTransactions = (0,transactions_hooks/* useAllTransactions */.kf)();
  const dispatch = (0,external_react_redux_.useDispatch)();
  const tx = allTransactions === null || allTransactions === void 0 ? void 0 : allTransactions[hash];
  const summary = tx === null || tx === void 0 ? void 0 : tx.summary;
  const pending = !(tx !== null && tx !== void 0 && tx.receipt);
  const success = !pending && tx && (((_tx$receipt = tx.receipt) === null || _tx$receipt === void 0 ? void 0 : _tx$receipt.status) === 1 || typeof ((_tx$receipt2 = tx.receipt) === null || _tx$receipt2 === void 0 ? void 0 : _tx$receipt2.status) === 'undefined');
  const archer = tx === null || tx === void 0 ? void 0 : tx.archer;
  const secondsUntilDeadline = (0,external_react_.useMemo)(() => calculateSecondsUntilDeadline(tx), [tx]);
  const mined = (tx === null || tx === void 0 ? void 0 : tx.receipt) && tx.receipt.status !== 1337;
  const cancelled = (tx === null || tx === void 0 ? void 0 : tx.receipt) && tx.receipt.status === 1337;
  const expired = secondsUntilDeadline === -1;
  const cancelPending = (0,external_react_.useCallback)(() => {
    var _process$env$NEXT_PUB;

    const relayURI = constants/* ARCHER_RELAY_URI */.HB[chainId];
    if (!relayURI) return;
    const body = JSON.stringify({
      method: 'archer_cancelTx',
      tx: archer === null || archer === void 0 ? void 0 : archer.rawTransaction
    });
    fetch(relayURI, {
      method: 'POST',
      body,
      headers: {
        Authorization: (_process$env$NEXT_PUB = process.env.NEXT_PUBLIC_ARCHER_API_KEY) !== null && _process$env$NEXT_PUB !== void 0 ? _process$env$NEXT_PUB : '',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      dispatch((0,actions/* finalizeTransaction */.Aw)({
        chainId,
        hash,
        receipt: {
          blockHash: '',
          blockNumber: 0,
          contractAddress: '',
          from: '',
          status: 1337,
          to: '',
          transactionHash: '',
          transactionIndex: 0
        }
      }));
    }).catch(err => console.error(err));
  }, [dispatch, chainId, archer, hash]);
  if (!chainId) return null;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col w-full gap-2 px-3 py-1 rounded bg-dark-800",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ExternalLink/* default */.Z, {
      href: (0,explorer/* getExplorerLink */.E)(chainId, hash, 'transaction'),
      className: "flex items-center gap-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
        variant: "sm",
        className: "flex items-center hover:underline py-0.5",
        children: [summary !== null && summary !== void 0 ? summary : hash, " \u2197"]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (0,functions/* classNames */.AK)(pending ? 'text-primary' : success ? 'text-green' : cancelled ? 'text-red' : 'text-red'),
        children: pending ? /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {}) : success ? /*#__PURE__*/jsx_runtime_.jsx(esm/* CheckCircleIcon */.rE2, {
          width: 16,
          height: 16
        }) : cancelled ? /*#__PURE__*/jsx_runtime_.jsx(esm/* XCircleIcon */.oOx, {
          width: 16,
          height: 16
        }) : /*#__PURE__*/jsx_runtime_.jsx(esm/* ExclamationIcon */.SI8, {
          width: 16,
          height: 16
        })
      })]
    }), archer && /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
      variant: "sm",
      weight: 400,
      className: "flex items-center justify-between pb-1 text-decoration-none",
      children: [`#${archer.nonce} - Tip ${sdk_.CurrencyAmount.fromRawAmount(sdk_.Ether.onChain(sdk_.ChainId.MAINNET), archer.ethTip).toSignificant(6)} ETH`, pending ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [secondsUntilDeadline >= 60 ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-high-emphesis",
          children: ["\uD83D\uDD51 ", `${Math.ceil(secondsUntilDeadline / 60)} mins`, " "]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-high-emphesis",
          children: ["\uD83D\uDD51 ", `<1 min`, " "]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center cursor-pointer",
          onClick: cancelPending,
          children: i18n._(
          /*i18n*/
          i18n._("Cancel"))
        })]
      }) : cancelled ? /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-red",
        children: i18n._(
        /*i18n*/
        i18n._("Cancelled"))
      }) : !mined && expired && /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-red",
        children: i18n._(
        /*i18n*/
        i18n._("Expired"))
      })]
    })]
  });
};

/* harmony default export */ const AccountDetails_Transaction = (Transaction);
;// CONCATENATED MODULE: ./src/components/AccountDetails/index.tsx





















const WalletIcon = ({
  size,
  src,
  alt,
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-row items-end justify-center mr-2 flex-nowrap md:items-center",
    children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: src,
      alt: alt,
      width: size,
      height: size
    }), children]
  });
};

function renderTransactions(transactions) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col gap-2 flex-nowrap",
    children: transactions.map((hash, i) => {
      return /*#__PURE__*/jsx_runtime_.jsx(AccountDetails_Transaction, {
        hash: hash
      }, i);
    })
  });
}

const AccountDetails = ({
  toggleWalletModal,
  pendingTransactions,
  confirmedTransactions,
  ENSName,
  openOptions
}) => {
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    chainId,
    account,
    connector
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const dispatch = (0,external_react_redux_.useDispatch)();

  function formatConnectorName() {
    const {
      ethereum
    } = window;
    const isMetaMask = !!(ethereum && ethereum.isMetaMask);
    const name = Object.keys(constants/* SUPPORTED_WALLETS */.Vp).filter(k => constants/* SUPPORTED_WALLETS */.Vp[k].connector === connector && (connector !== connectors/* injected */.Lj || isMetaMask === (k === 'METAMASK'))).map(k => constants/* SUPPORTED_WALLETS */.Vp[k].name)[0];
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "font-medium text-baseline text-secondary",
      children: ["Connected with ", name]
    });
  }

  function getStatusIcon() {
    if (connector === connectors/* injected */.Lj) {
      return null; // return <IconWrapper size={16}>{/* <Identicon /> */}</IconWrapper>
    } else if (connector.constructor.name === 'WalletConnectConnector') {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/wallet-connect.png",
        alt: "Wallet Connect",
        size: 16
      });
    } else if (connector.constructor.name === 'WalletLinkConnector') {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/coinbase.svg",
        alt: "Coinbase",
        size: 16
      });
    } else if (connector.constructor.name === 'FortmaticConnector') {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/formatic.png",
        alt: "Fortmatic",
        size: 16
      });
    } else if (connector.constructor.name === 'PortisConnector') {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/portnis.png",
        alt: "Portis",
        size: 16,
        children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          onClick: async () => {
            // casting as PortisConnector here defeats the lazyload purpose
            ;
            connector.portis.showPortis();
          },
          children: "Show Portis"
        })
      });
    } else if (connector.constructor.name === 'TorusConnector') {
      return /*#__PURE__*/jsx_runtime_.jsx(WalletIcon, {
        src: "/torus.png",
        alt: "Torus",
        size: 16
      });
    }

    return null;
  }

  const clearAllTransactionsCallback = (0,external_react_.useCallback)(() => {
    if (chainId) dispatch((0,actions/* clearAllTransactions */.fY)({
      chainId
    }));
  }, [dispatch, chainId]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "space-y-3",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "space-y-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
        title: "Account",
        onClose: toggleWalletModal
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-3",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between",
          children: [formatConnectorName(), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex space-x-3",
            children: [connector !== connectors/* injected */.Lj && connector.constructor.name !== 'WalletLinkConnector' && connector.constructor.name !== 'BscConnector' && connector.constructor.name !== 'KeystoneConnector' && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "gray",
              size: "xs",
              onClick: () => {
                ;
                connector.close();
              },
              children: i18n._(
              /*i18n*/
              i18n._("Disconnect"))
            }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "gray",
              size: "xs",
              onClick: () => {
                openOptions();
              },
              children: i18n._(
              /*i18n*/
              i18n._("Change"))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          id: "web3-account-identifier-row",
          className: "flex flex-col justify-center space-y-3",
          children: [ENSName ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "bg-dark-800",
            children: [getStatusIcon(), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              children: ENSName
            })]
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "px-3 py-2 rounded bg-dark-800",
            children: [getStatusIcon(), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              children: account && (0,functions/* shortenAddress */.Xn)(account)
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center gap-2 space-x-3",
            children: [chainId && account && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
              color: "blue",
              startIcon: /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.ExternalLink, {
                size: 16
              }),
              href: chainId && (0,explorer/* getExplorerLink */.E)(chainId, ENSName || account, 'address'),
              children: /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
                variant: "sm",
                children: i18n._(
                /*i18n*/
                i18n._("View on explorer"))
              })
            }), account && /*#__PURE__*/jsx_runtime_.jsx(Copy, {
              toCopy: account,
              children: /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
                variant: "sm",
                children: i18n._(
                /*i18n*/
                i18n._("Copy Address"))
              })
            })]
          })]
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "space-y-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          weight: 700,
          children: i18n._(
          /*i18n*/
          i18n._("Recent Transactions"))
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            variant: "outlined",
            color: "gray",
            size: "xs",
            onClick: clearAllTransactionsCallback,
            children: i18n._(
            /*i18n*/
            i18n._("Clear all"))
          })
        })]
      }), !!pendingTransactions.length || !!confirmedTransactions.length ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [renderTransactions(pendingTransactions), renderTransactions(confirmedTransactions)]
      }) : /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
        variant: "sm",
        className: "text-secondary",
        children: i18n._(
        /*i18n*/
        i18n._("Your transactions will appear here..."))
      })]
    })]
  });
};

/* harmony default export */ const components_AccountDetails = (AccountDetails);
// EXTERNAL MODULE: ./src/state/application/actions.ts
var application_actions = __webpack_require__(434);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(1441);
// EXTERNAL MODULE: external "@web3-react/fortmatic-connector"
var fortmatic_connector_ = __webpack_require__(1698);
;// CONCATENATED MODULE: ./src/connectors/Fortmatic.ts


const OVERLAY_READY = 'OVERLAY_READY';
const CHAIN_ID_NETWORK_ARGUMENT = {
  [sdk_.ChainId.MAINNET]: undefined,
  [sdk_.ChainId.ROPSTEN]: 'ropsten',
  [sdk_.ChainId.RINKEBY]: 'rinkeby',
  [sdk_.ChainId.KOVAN]: 'kovan'
};
class FortmaticConnector extends (/* unused pure expression or super */ null && (FortmaticConnectorCore)) {
  async activate() {
    if (!this.fortmatic) {
      const {
        default: Fortmatic
      } = await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8728, 23));
      const {
        apiKey,
        chainId
      } = this;

      if (chainId in CHAIN_ID_NETWORK_ARGUMENT) {
        this.fortmatic = new Fortmatic(apiKey, CHAIN_ID_NETWORK_ARGUMENT[chainId]);
      } else {
        throw new Error(`Unsupported network ID: ${chainId}`);
      }
    }

    const provider = this.fortmatic.getProvider();
    const pollForOverlayReady = new Promise(resolve => {
      const interval = setInterval(() => {
        if (provider.overlayReady) {
          clearInterval(interval);
          this.emit(OVERLAY_READY);
          resolve();
        }
      }, 200);
    });
    const [account] = await Promise.all([provider.enable().then(accounts => accounts[0]), pollForOverlayReady]);
    return {
      provider: this.fortmatic.getProvider(),
      chainId: this.chainId,
      account
    };
  }

}
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./src/modals/WalletModal/Option.tsx





const SubHeader = external_styled_components_default().div.withConfig({
  displayName: "Option__SubHeader",
  componentId: "sc-1melv9r-0"
})(["margin-top:10px;font-size:12px;"]);
function Option({
  link = null,
  clickable = true,
  size,
  onClick = null,
  color,
  header,
  subheader = null,
  icon,
  active = false,
  id
}) {
  const content = /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: onClick,
    className: `flex items-center justify-between w-full p-3 rounded cursor-pointer ${!active ? 'bg-dark-800 hover:bg-dark-700' : 'bg-dark-1000'}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [active && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-4 h-4 mr-4 rounded-full",
          style: {
            background: color
          }
        }), header]
      }), subheader && /*#__PURE__*/jsx_runtime_.jsx(SubHeader, {
        children: subheader
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: icon,
      alt: 'Icon',
      width: "32px",
      height: "32px"
    })]
  });

  if (link) {
    return /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: link,
      children: content
    });
  }

  return !active ? content : /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "w-full p-px rounded bg-gradient-to-r from-blue to-pink",
    children: content
  });
}
// EXTERNAL MODULE: ./src/components/Dots/index.tsx
var Dots = __webpack_require__(8561);
// EXTERNAL MODULE: external "polished"
var external_polished_ = __webpack_require__(7158);
;// CONCATENATED MODULE: ./src/modals/WalletModal/PendingView.tsx










const PendingSection = external_styled_components_default().div.withConfig({
  displayName: "PendingView__PendingSection",
  componentId: "sc-1qnlplp-0"
})(["align-items:center;justify-content:center;width:100%;& > *{width:100%;}"]);
const StyledLoader = external_styled_components_default()(Loader/* default */.Z).withConfig({
  displayName: "PendingView__StyledLoader",
  componentId: "sc-1qnlplp-1"
})(["margin-right:1rem;"]);
const LoadingMessage = external_styled_components_default().div.withConfig({
  displayName: "PendingView__LoadingMessage",
  componentId: "sc-1qnlplp-2"
})(["align-items:center;justify-content:flex-start;margin-bottom:20px;& > *{padding:1rem;}"]);
const ErrorGroup = external_styled_components_default().div.withConfig({
  displayName: "PendingView__ErrorGroup",
  componentId: "sc-1qnlplp-3"
})(["align-items:center;justify-content:flex-start;"]);
const ErrorButton = external_styled_components_default().div.withConfig({
  displayName: "PendingView__ErrorButton",
  componentId: "sc-1qnlplp-4"
})(["border-radius:8px;font-size:12px;margin-left:1rem;padding:0.5rem;font-weight:600;user-select:none;&:hover{cursor:pointer;}"]);
const LoadingWrapper = external_styled_components_default().div.withConfig({
  displayName: "PendingView__LoadingWrapper",
  componentId: "sc-1qnlplp-5"
})(["align-items:center;justify-content:center;"]);
function PendingView({
  connector,
  error = false,
  setPendingError,
  tryActivation
}) {
  var _window, _window$ethereum;

  const isMetamask = (_window = window) === null || _window === void 0 ? void 0 : (_window$ethereum = _window.ethereum) === null || _window$ethereum === void 0 ? void 0 : _window$ethereum.isMetaMask;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(PendingSection, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(LoadingMessage, {
      error: error,
      children: /*#__PURE__*/jsx_runtime_.jsx(LoadingWrapper, {
        children: error ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(ErrorGroup, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            children: "Error connecting."
          }), /*#__PURE__*/jsx_runtime_.jsx(ErrorButton, {
            onClick: () => {
              setPendingError(false);
              connector && tryActivation(connector);
            },
            children: "Try Again"
          })]
        }) : /*#__PURE__*/jsx_runtime_.jsx(Dots/* default */.Z, {
          children: "Initializing"
        })
      })
    }), Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      const option = constants/* SUPPORTED_WALLETS */.Vp[key];

      if (option.connector === connector) {
        if (option.connector === connectors/* injected */.Lj) {
          if (isMetamask && option.name !== 'MetaMask') {
            return null;
          }

          if (!isMetamask && option.name === 'MetaMask') {
            return null;
          }
        }

        return /*#__PURE__*/jsx_runtime_.jsx(Option, {
          id: `connect-${key}`,
          clickable: false,
          color: option.color,
          header: option.name,
          subheader: option.description,
          icon: '/images/wallets/' + option.iconName
        }, key);
      }

      return null;
    })]
  });
}
// EXTERNAL MODULE: external "react-ga"
var external_react_ga_ = __webpack_require__(9831);
var external_react_ga_default = /*#__PURE__*/__webpack_require__.n(external_react_ga_);
// EXTERNAL MODULE: external "@web3-react/walletconnect-connector"
var walletconnect_connector_ = __webpack_require__(9650);
// EXTERNAL MODULE: external "react-device-detect"
var external_react_device_detect_ = __webpack_require__(2047);
// EXTERNAL MODULE: ./src/hooks/usePrevious.ts
var usePrevious = __webpack_require__(4751);
;// CONCATENATED MODULE: ./src/modals/WalletModal/index.tsx























const CloseIcon = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__CloseIcon",
  componentId: "sc-ljfs0f-0"
})(["position:absolute;right:0;top:0;&:hover{cursor:pointer;opacity:0.6;}"]);
const HeaderRow = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__HeaderRow",
  componentId: "sc-ljfs0f-1"
})(["margin-bottom:1rem;"]);
const UpperSection = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__UpperSection",
  componentId: "sc-ljfs0f-2"
})(["position:relative;h5{margin:0;margin-bottom:0.5rem;font-size:1rem;font-weight:400;}h5:last-child{margin-bottom:0px;}h4{margin-top:0;font-weight:500;}"]);
const OptionGrid = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__OptionGrid",
  componentId: "sc-ljfs0f-3"
})(["display:grid;grid-gap:10px;grid-template-columns:1fr;"]);
const HoverText = external_styled_components_default().div.withConfig({
  displayName: "WalletModal__HoverText",
  componentId: "sc-ljfs0f-4"
})([":hover{cursor:pointer;}"]);
const WALLET_VIEWS = {
  OPTIONS: 'options',
  OPTIONS_SECONDARY: 'options_secondary',
  ACCOUNT: 'account',
  PENDING: 'pending'
};
function WalletModal({
  pendingTransactions,
  confirmedTransactions,
  ENSName
}) {
  // console.log({ ENSName })
  // important that these are destructed from the account-specific web3-react context
  const {
    active,
    account,
    connector,
    activate,
    error,
    deactivate
  } = (0,core_.useWeb3React)();
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    0: walletView,
    1: setWalletView
  } = (0,external_react_.useState)(WALLET_VIEWS.ACCOUNT);
  const {
    0: pendingWallet,
    1: setPendingWallet
  } = (0,external_react_.useState)();
  const {
    0: pendingError,
    1: setPendingError
  } = (0,external_react_.useState)();
  const walletModalOpen = (0,hooks/* useModalOpen */.oL)(application_actions/* ApplicationModal.WALLET */.Lk.WALLET);
  const toggleWalletModal = (0,hooks/* useWalletModalToggle */.mq)();
  const previousAccount = (0,usePrevious/* default */.Z)(account); // close on connection, when logged out before

  (0,external_react_.useEffect)(() => {
    if (account && !previousAccount && walletModalOpen) {
      toggleWalletModal();
    }
  }, [account, previousAccount, toggleWalletModal, walletModalOpen]); // always reset to account view

  (0,external_react_.useEffect)(() => {
    if (walletModalOpen) {
      setPendingError(false);
      setWalletView(WALLET_VIEWS.ACCOUNT);
    }
  }, [walletModalOpen]); // close modal when a connection is successful

  const activePrevious = (0,usePrevious/* default */.Z)(active);
  const connectorPrevious = (0,usePrevious/* default */.Z)(connector);
  (0,external_react_.useEffect)(() => {
    if (walletModalOpen && (active && !activePrevious || connector && connector !== connectorPrevious && !error)) {
      setWalletView(WALLET_VIEWS.ACCOUNT);
    }
  }, [setWalletView, active, error, connector, walletModalOpen, activePrevious, connectorPrevious]);

  const tryActivation = async connector => {
    var _conn$walletConnectPr, _conn$walletConnectPr2;

    let name = '';
    let conn = typeof connector === 'function' ? await connector() : connector;
    Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      if (connector === constants/* SUPPORTED_WALLETS */.Vp[key].connector) {
        return name = constants/* SUPPORTED_WALLETS */.Vp[key].name;
      }

      return true;
    }); // log selected wallet

    external_react_ga_default().event({
      category: 'Wallet',
      action: 'Change Wallet',
      label: name
    });
    setPendingWallet(conn); // set wallet for pending view

    setWalletView(WALLET_VIEWS.PENDING); // if the connector is walletconnect and the user has already tried to connect, manually reset the connector

    if (conn instanceof walletconnect_connector_.WalletConnectConnector && (_conn$walletConnectPr = conn.walletConnectProvider) !== null && _conn$walletConnectPr !== void 0 && (_conn$walletConnectPr2 = _conn$walletConnectPr.wc) !== null && _conn$walletConnectPr2 !== void 0 && _conn$walletConnectPr2.uri) {
      conn.walletConnectProvider = undefined;
    }

    conn && activate(conn, undefined, true).catch(error => {
      if (error instanceof core_.UnsupportedChainIdError) {
        activate(conn); // a little janky...can't use setError because the connector isn't set
      } else {
        setPendingError(true);
      }
    });
  }; // close wallet modal if fortmatic modal is active


  (0,external_react_.useEffect)(() => {
    var _connector$constructo;

    if ((connector === null || connector === void 0 ? void 0 : (_connector$constructo = connector.constructor) === null || _connector$constructo === void 0 ? void 0 : _connector$constructo.name) === 'FormaticConnector') {
      connector.on(OVERLAY_READY, () => {
        toggleWalletModal();
      });
    }
  }, [toggleWalletModal, connector]); // get wallets user can switch too, depending on device/browser

  function getOptions() {
    const isMetamask = window.ethereum && window.ethereum.isMetaMask;
    return Object.keys(constants/* SUPPORTED_WALLETS */.Vp).map(key => {
      const option = constants/* SUPPORTED_WALLETS */.Vp[key]; // check for mobile options

      if (external_react_device_detect_.isMobile) {
        // disable portis on mobile for now
        if (option.name === 'Portis') {
          return null;
        }

        if (!window.web3 && !window.ethereum && option.mobile) {
          return /*#__PURE__*/jsx_runtime_.jsx(Option, {
            onClick: () => {
              tryActivation(option.connector);
            },
            id: `connect-${key}`,
            active: option.connector && option.connector === connector,
            color: option.color,
            link: option.href,
            header: option.name,
            subheader: null,
            icon: '/images/wallets/' + option.iconName
          }, key);
        }

        return null;
      } // overwrite injected when needed


      if (option.connector === connectors/* injected */.Lj) {
        // don't show injected if there's no injected provider
        if (!(window.web3 || window.ethereum)) {
          if (option.name === 'MetaMask') {
            return /*#__PURE__*/jsx_runtime_.jsx(Option, {
              id: `connect-${key}`,
              color: '#E8831D',
              header: 'Install Metamask',
              subheader: null,
              link: 'https://metamask.io/',
              icon: "/images/wallets/metamask.png"
            }, key);
          } else {
            return null; // dont want to return install twice
          }
        } // don't return metamask if injected provider isn't metamask
        else if (option.name === 'MetaMask' && !isMetamask) {
            return null;
          } // likewise for generic
          else if (option.name === 'Injected' && isMetamask) {
              return null;
            }
      } // return rest of options


      return !external_react_device_detect_.isMobile && !option.mobileOnly && /*#__PURE__*/jsx_runtime_.jsx(Option, {
        id: `connect-${key}`,
        onClick: () => {
          option.connector === connector ? setWalletView(WALLET_VIEWS.ACCOUNT) : !option.href && tryActivation(option.connector);
        },
        active: option.connector === connector,
        color: option.color,
        link: option.href,
        header: option.name,
        subheader: null // use option.descriptio to bring back multi-line
        ,
        icon: '/images/wallets/' + option.iconName
      }, key);
    });
  }

  function getModalContent() {
    if (error) {
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)(UpperSection, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(CloseIcon, {
          onClick: toggleWalletModal,
          children: /*#__PURE__*/jsx_runtime_.jsx(esm/* XIcon */.b0D, {
            width: "24px",
            height: "24px"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(HeaderRow, {
          style: {
            paddingLeft: 0,
            paddingRight: 0
          },
          children: error instanceof core_.UnsupportedChainIdError ? i18n._(
          /*i18n*/
          i18n._("Wrong Network")) : i18n._(
          /*i18n*/
          i18n._("Error connecting"))
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [error instanceof core_.UnsupportedChainIdError ? /*#__PURE__*/jsx_runtime_.jsx("h5", {
            children: i18n._(
            /*i18n*/
            i18n._("Please connect to the appropriate Ethereum network."))
          }) : i18n._(
          /*i18n*/
          i18n._("Error connecting. Try refreshing the page.")), /*#__PURE__*/jsx_runtime_.jsx("div", {
            style: {
              marginTop: '1rem'
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(Button/* ButtonError */.Kd, {
            error: true,
            size: "sm",
            onClick: deactivate,
            children: i18n._(
            /*i18n*/
            i18n._("Disconnect"))
          })]
        })]
      });
    }

    if (account && walletView === WALLET_VIEWS.ACCOUNT) {
      return /*#__PURE__*/jsx_runtime_.jsx(components_AccountDetails, {
        toggleWalletModal: toggleWalletModal,
        pendingTransactions: pendingTransactions,
        confirmedTransactions: confirmedTransactions,
        ENSName: ENSName,
        openOptions: () => setWalletView(WALLET_VIEWS.OPTIONS)
      });
    }

    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col space-y-4",
      children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
        title: "Select a Wallet",
        onClose: toggleWalletModal
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col space-y-6",
        children: [walletView === WALLET_VIEWS.PENDING ? /*#__PURE__*/jsx_runtime_.jsx(PendingView, {
          connector: pendingWallet,
          error: pendingError,
          setPendingError: setPendingError,
          tryActivation: tryActivation
        }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-col space-y-5 overflow-y-auto",
          children: getOptions()
        }), walletView !== WALLET_VIEWS.PENDING && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col text-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-secondary",
            children: i18n._(
            /*i18n*/
            i18n._("New to Ethereum?"))
          }), /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
            href: "https://ethereum.org/wallets/",
            color: "blue",
            children: i18n._(
            /*i18n*/
            i18n._("Learn more about wallets"))
          })]
        })]
      })]
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(Modal/* default */.Z, {
    isOpen: walletModalOpen,
    onDismiss: toggleWalletModal,
    minHeight: 0,
    maxHeight: 90,
    children: getModalContent()
  });
}
// EXTERNAL MODULE: ./src/components/Web3Connect/index.tsx
var Web3Connect = __webpack_require__(1394);
// EXTERNAL MODULE: ./src/functions/format.ts
var format = __webpack_require__(8277);
// EXTERNAL MODULE: ./src/hooks/useENSName.ts
var useENSName = __webpack_require__(7816);
;// CONCATENATED MODULE: ./src/components/Web3Status/index.tsx

















const IconWrapper = external_styled_components_default().div.withConfig({
  displayName: "Web3Status__IconWrapper",
  componentId: "sc-ii8b62-0"
})(["display:flex;flex-flow:column nowrap;align-items:center;justify-content:center;& > *{height:", ";width:", ";}"], ({
  size
}) => size ? size + 'px' : '32px', ({
  size
}) => size ? size + 'px' : '32px'); // we want the latest one to come first, so return negative if a is after b

function newTransactionsFirst(a, b) {
  return b.addedTime - a.addedTime;
}

const SOCK = /*#__PURE__*/jsx_runtime_.jsx("span", {
  role: "img",
  "aria-label": "has socks emoji",
  style: {
    marginTop: -4,
    marginBottom: -4
  },
  children: "\uD83E\uDDE6"
}); // eslint-disable-next-line react/prop-types


function StatusIcon({
  connector
}) {
  if (connector === connectors/* injected */.Lj) {
    return /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      src: "/chef.svg",
      alt: "Injected (MetaMask etc...)",
      width: 20,
      height: 20
    }); // return <Identicon />
  } else if (connector.constructor.name === 'WalletConnectConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/wallet-connect.png",
        alt: 'Wallet Connect',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'LatticeConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/lattice.png",
        alt: 'Lattice',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'WalletLinkConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/coinbase.svg",
        alt: 'Coinbase Wallet',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'FortmaticConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/fortmatic.png",
        alt: 'Fortmatic',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'PortisConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/portis.png",
        alt: 'Portis',
        width: "16px",
        height: "16px"
      })
    });
  } else if (connector.constructor.name === 'KeystoneConnector') {
    return /*#__PURE__*/jsx_runtime_.jsx(IconWrapper, {
      size: 16,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: "/images/wallets/keystone.png",
        alt: 'Keystone',
        width: "16px",
        height: "16px"
      })
    });
  }

  return null;
}

function Web3StatusInner() {
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    account,
    connector
  } = (0,core_.useWeb3React)();
  const {
    ENSName
  } = (0,useENSName/* default */.Z)(account !== null && account !== void 0 ? account : undefined);
  const allTransactions = (0,transactions_hooks/* useAllTransactions */.kf)();
  const sortedRecentTransactions = (0,external_react_.useMemo)(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(transactions_hooks/* isTransactionRecent */.mH).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => {
    if (tx.receipt) {
      return false;
    } else if (tx.archer && tx.archer.deadline * 1000 - Date.now() < 0) {
      return false;
    } else {
      return true;
    }
  }).map(tx => tx.hash);
  const hasPendingTransactions = !!pending.length;
  const toggleWalletModal = (0,hooks/* useWalletModalToggle */.mq)();

  if (account) {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "web3-status-connected",
      className: "flex items-center px-3 py-2 text-sm rounded-lg bg-dark-1000 text-secondary",
      onClick: toggleWalletModal,
      children: [hasPendingTransactions ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "pr-2",
          children: [pending === null || pending === void 0 ? void 0 : pending.length, " ", i18n._(
          /*i18n*/
          i18n._("Pending"))]
        }), ' ', /*#__PURE__*/jsx_runtime_.jsx(Loader/* default */.Z, {
          stroke: "white"
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mr-2",
        children: ENSName || (0,format/* shortenAddress */.Xn)(account)
      }), !hasPendingTransactions && connector && /*#__PURE__*/jsx_runtime_.jsx(StatusIcon, {
        connector: connector
      })]
    });
  } else {
    return /*#__PURE__*/jsx_runtime_.jsx(Web3Connect/* default */.Z, {
      style: {
        paddingTop: '6px',
        paddingBottom: '6px'
      }
    });
  }
}

function Web3Status() {
  const {
    active,
    account
  } = (0,core_.useWeb3React)();
  const contextNetwork = (0,core_.useWeb3React)(constants/* NetworkContextName */.AQ);
  const {
    ENSName
  } = (0,useENSName/* default */.Z)(account !== null && account !== void 0 ? account : undefined);
  const allTransactions = (0,transactions_hooks/* useAllTransactions */.kf)();
  const sortedRecentTransactions = (0,external_react_.useMemo)(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(transactions_hooks/* isTransactionRecent */.mH).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => !tx.receipt).map(tx => tx.hash);
  const confirmed = sortedRecentTransactions.filter(tx => tx.receipt).map(tx => tx.hash);

  if (!contextNetwork.active && !active) {
    return null;
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Web3StatusInner, {}), /*#__PURE__*/jsx_runtime_.jsx(WalletModal, {
      ENSName: ENSName !== null && ENSName !== void 0 ? ENSName : undefined,
      pendingTransactions: pending,
      confirmedTransactions: confirmed
    })]
  });
}
// EXTERNAL MODULE: ./src/state/wallet/hooks.ts
var wallet_hooks = __webpack_require__(2319);
;// CONCATENATED MODULE: ./src/components/Header/index.tsx














 // import { ExternalLink, NavLink } from "./Link";
// import { ReactComponent as Burger } from "../assets/images/burger.svg";

function AppBar() {
  var _useETHBalances;

  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    account,
    chainId,
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const userEthBalance = (_useETHBalances = (0,wallet_hooks/* useETHBalances */.AE)(account ? [account] : [])) === null || _useETHBalances === void 0 ? void 0 : _useETHBalances[account !== null && account !== void 0 ? account : ''];
  return (
    /*#__PURE__*/
    //     // <header className="flex flex-row justify-between w-screen flex-nowrap">
    jsx_runtime_.jsx("header", {
      className: "flex-shrink-0 w-full",
      children: /*#__PURE__*/jsx_runtime_.jsx(react_.Popover, {
        as: "nav",
        className: "z-10 w-full bg-transparent header-border-b",
        children: ({
          open
        }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "px-4 py-4",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex items-center justify-between",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: "/gwf.png",
                  alt: "GWFDex",
                  width: "32px",
                  height: "32px"
                }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "hidden sm:block sm:ml-4",
                  children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "flex space-x-2",
                    children: [/*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: "/swap",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `swap-nav-link`,
                        className: "p-2 text-baseline text-blue hover:text-cyan-blue focus:font-bold md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Swap"))
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: "/pool",
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `pool-nav-link`,
                        className: "p-2 text-baseline text-blue hover:text-cyan-blue focus:font-bold md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Pool"))
                      })
                    }), chainId && chainId === sdk_.ChainId.GWFU && /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: '/farm',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `farm-nav-link`,
                        className: "p-2 text-baseline text-blue hover:text-cyan-blue focus:font-bold md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Farm"))
                      })
                    }), chainId && chainId === sdk_.ChainId.GWFU && /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
                      href: '/stake',
                      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                        id: `farm-nav-link`,
                        className: "p-2 text-baseline text-blue hover:text-cyan-blue focus:font-bold md:p-3 whitespace-nowrap",
                        children: i18n._(
                        /*i18n*/
                        i18n._("Stake"))
                      })
                    })]
                  })
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "fixed bottom-0 left-0 z-10 flex flex-row items-center justify-center w-full p-4 lg:w-auto bg-dark-1000 lg:relative lg:p-0 lg:bg-transparent",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "flex items-center justify-between w-full space-x-2 sm:justify-end",
                  children: [library && library.provider.isMetaMask && /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "hidden sm:inline-block",
                    children: /*#__PURE__*/jsx_runtime_.jsx(components_Web3Network, {})
                  }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "w-auto flex items-center rounded bg-dark-green hover:bg-green p-0.5 whitespace-nowrap text-sm font-bold cursor-pointer select-none pointer-events-auto",
                    children: [account && chainId && userEthBalance && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "px-3 py-2 text-white text-bold",
                        children: [userEthBalance === null || userEthBalance === void 0 ? void 0 : userEthBalance.toSignificant(4), " ", sdk_.NATIVE[chainId].symbol]
                      })
                    }), /*#__PURE__*/jsx_runtime_.jsx(Web3Status, {})]
                  })]
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex -mr-2 sm:hidden",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Popover.Button, {
                  className: "inline-flex items-center justify-center p-2 rounded-md text-primary hover:text-high-emphesis focus:outline-none",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "sr-only",
                    children: i18n._(
                    /*i18n*/
                    i18n._("Open main menu"))
                  }), open ? /*#__PURE__*/jsx_runtime_.jsx("svg", {
                    className: "block w-6 h-6",
                    "aria-hidden": "true",
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "2",
                      d: "M6 18L18 6M6 6l12 12"
                    })
                  }) :
                  /*#__PURE__*/
                  // <X title="Close" className="block w-6 h-6" aria-hidden="true" />
                  jsx_runtime_.jsx("svg", {
                    className: "block w-6 h-6",
                    "aria-hidden": "true",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    stroke: "currentColor",
                    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: 2,
                      d: "M4 6h16M4 12h16M4 18h16"
                    })
                  }) // <Burger title="Burger" className="block w-6 h-6" aria-hidden="true" />
                  ]
                })
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(react_.Popover.Panel, {
            className: "sm:hidden",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col px-4 pt-2 pb-3 space-y-1",
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/swap',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `swap-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Swap"))
                })
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/pool',
                children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                  id: `pool-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: i18n._(
                  /*i18n*/
                  i18n._("Pool"))
                })
              }), chainId && (0,feature/* featureEnabled */.vR)(feature/* Feature.LIQUIDITY_MINING */.L0.LIQUIDITY_MINING, chainId) && /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: '/farm',
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                  id: `farm-nav-link`,
                  className: "p-2 text-baseline text-primary hover:text-high-emphesis focus:text-high-emphesis md:p-3 whitespace-nowrap",
                  children: [' ', i18n._(
                  /*i18n*/
                  i18n._("Farm"))]
                })
              })]
            })
          })]
        })
      })
    })
  );
}

/* harmony default export */ const Header = (AppBar);

/***/ }),

/***/ 6659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const Main = ({
  children
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
  className: "flex flex-col items-center justify-start flex-grow w-full h-full",
  style: {
    height: 'max-content'
  },
  children: children
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);

/***/ }),

/***/ 4751:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ usePrevious)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/usePrevious/

function usePrevious(value) {
  // The ref object is a generic container whose current property is mutable ...
  // ... and can hold any value, similar to an instance property on a class
  const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(); // Store current value in ref

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    ref.current = value;
  }, [value]); // Only re-run if value changes
  // Return previous value (happens before update in useEffect above)

  return ref.current;
}

/***/ }),

/***/ 6430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "id": () => (/* binding */ useBentoBalances),
  "B2": () => (/* binding */ useBentoMasterContractAllowed)
});

// UNUSED EXPORTS: useBentoBalance

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 33 modules
var hooks_useContract = __webpack_require__(1263);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(1446);
// EXTERNAL MODULE: ./src/constants/abis/erc20.json
var erc20 = __webpack_require__(9638);
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var hooks = __webpack_require__(9202);
// EXTERNAL MODULE: ./src/functions/math.ts
var math = __webpack_require__(9247);
// EXTERNAL MODULE: ./src/functions/kashi.ts + 1 modules
var kashi = __webpack_require__(9867);
// EXTERNAL MODULE: external "@ethersproject/address"
var address_ = __webpack_require__(7398);
// EXTERNAL MODULE: ./src/functions/bentobox.ts
var bentobox = __webpack_require__(4218);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/hooks/Tokens.ts
var Tokens = __webpack_require__(6269);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var multicall_hooks = __webpack_require__(879);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var transactions_hooks = __webpack_require__(9123);
;// CONCATENATED MODULE: ./src/hooks/useTransactionStatus.ts



// we want the latest one to come first, so return negative if a is after b
function newTransactionsFirst(a, b) {
  return b.addedTime - a.addedTime;
}

const useTransactionStatus_useTransactionStatus = () => {
  const {
    0: pendingTXStatus,
    1: setPendingTXStatus
  } = useState(false); // Determine if change in transactions, if so, run query again

  const allTransactions = useAllTransactions();
  const sortedRecentTransactions = useMemo(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(isTransactionRecent).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => !tx.receipt).map(tx => tx.hash);
  const hasPendingTransactions = !!pending.length;
  useEffect(() => {
    setPendingTXStatus(hasPendingTransactions);
  }, [hasPendingTransactions]);
  return pendingTXStatus;
};

/* harmony default export */ const hooks_useTransactionStatus = ((/* unused pure expression or super */ null && (useTransactionStatus_useTransactionStatus)));
;// CONCATENATED MODULE: ./src/state/bentobox/hooks.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















function useBentoBalances() {
  const {
    chainId,
    account
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  const boringHelperContract = (0,hooks_useContract/* useBoringHelperContract */.HW)();
  const tokens = (0,Tokens/* useAllTokens */.e_)();
  const weth = sdk_.WNATIVE_ADDRESS[chainId];
  const tokenAddresses = Object.keys(tokens);
  const balanceData = (0,multicall_hooks/* useSingleCallResult */.Wk)(boringHelperContract, 'getBalances', [account, tokenAddresses]);
  const uiData = (0,multicall_hooks/* useSingleCallResult */.Wk)(boringHelperContract, 'getUIInfo', [account, [], hooks/* USDC */.gn[chainId].address, [sdk_.KASHI_ADDRESS[chainId]]]); // IERC20 token = addresses[i];
  // balances[i].totalSupply = token.totalSupply();
  // balances[i].token = token;
  // balances[i].balance = token.balanceOf(who);
  // balances[i].bentoAllowance = token.allowance(who, address(bentoBox));
  // balances[i].nonce = token.nonces(who);
  // balances[i].bentoBalance = bentoBox.balanceOf(token, who);
  // (balances[i].bentoAmount, balances[i].bentoShare) = bentoBox.totals(token);
  // balances[i].rate = getETHRate(token);

  return (0,external_react_.useMemo)(() => {
    if (uiData.loading || balanceData.loading || uiData.error || balanceData.error || !uiData.result || !balanceData.result) return [];
    return tokenAddresses.map((key, i) => {
      const token = tokens[key];
      const usd = (0,math/* e10 */.TB)(token.decimals).mulDiv(uiData.result[0].ethRate, balanceData.result[0][i].rate);

      const full = _objectSpread(_objectSpread(_objectSpread({}, token), balanceData.result[0][i]), {}, {
        usd
      });

      return _objectSpread(_objectSpread({}, token), {}, {
        usd,
        address: token.address,
        name: token.name,
        symbol: token.symbol,
        decimals: token.decimals,
        balance: token.address === weth ? uiData.result[0].ethBalance : balanceData.result[0][i].balance,
        bentoBalance: balanceData.result[0][i].bentoBalance,
        wallet: (0,kashi/* easyAmount */.bi)(token.address === weth ? uiData.result[0].ethBalance : balanceData.result[0][i].balance, full),
        bento: (0,kashi/* easyAmount */.bi)((0,bentobox/* toAmount */.s)(full, balanceData.result[0][i].bentoBalance), full)
      });
    }).filter(token => token.balance.gt('0') || token.bentoBalance.gt('0'));
  }, [uiData.loading, uiData.error, uiData.result, balanceData.loading, balanceData.error, balanceData.result, tokenAddresses, tokens, weth]);
}
function useBentoBalance(tokenAddress) {
  const {
    account
  } = useActiveWeb3React();
  const boringHelperContract = useBoringHelperContract();
  const bentoBoxContract = useBentoBoxContract();
  const tokenAddressChecksum = getAddress(tokenAddress);
  const tokenContract = useContract(tokenAddressChecksum ? tokenAddressChecksum : undefined, ERC20_ABI);
  const currentTransactionStatus = useTransactionStatus();
  const {
    0: balance,
    1: setBalance
  } = useState(); // const balanceData = useSingleCallResult(boringHelperContract, 'getBalances', [account, tokenAddresses])

  const fetchBentoBalance = useCallback(async () => {
    const balances = await (boringHelperContract === null || boringHelperContract === void 0 ? void 0 : boringHelperContract.getBalances(account, [tokenAddressChecksum]));
    const decimals = await (tokenContract === null || tokenContract === void 0 ? void 0 : tokenContract.decimals());
    const amount = BigNumber.from(balances[0].bentoShare).isZero() ? BigNumber.from(0) : BigNumber.from(balances[0].bentoBalance).mul(BigNumber.from(balances[0].bentoAmount)).div(BigNumber.from(balances[0].bentoShare));
    setBalance({
      value: amount,
      decimals: decimals
    });
  }, [account, tokenAddressChecksum, tokenContract, boringHelperContract]);
  useEffect(() => {
    if (account && bentoBoxContract && boringHelperContract && tokenContract) {
      fetchBentoBalance();
    }
  }, [account, bentoBoxContract, currentTransactionStatus, fetchBentoBalance, tokenContract, boringHelperContract]);
  return balance;
}
function useBentoMasterContractAllowed(masterContract, user) {
  const contract = (0,hooks_useContract/* useBentoBoxContract */.rO)();
  const inputs = (0,external_react_.useMemo)(() => [masterContract, user], [masterContract, user]);
  const allowed = (0,multicall_hooks/* useSingleCallResult */.Wk)(contract, 'masterContractApproved', inputs).result;
  return (0,external_react_.useMemo)(() => allowed ? allowed[0] : undefined, [allowed]);
}

/***/ })

};
;