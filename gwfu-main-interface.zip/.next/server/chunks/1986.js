"use strict";
exports.id = 1986;
exports.ids = [1986];
exports.modules = {

/***/ 1986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L0": () => (/* binding */ Feature),
/* harmony export */   "vR": () => (/* binding */ featureEnabled),
/* harmony export */   "x$": () => (/* binding */ chainsWithFeature)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

let Feature;

(function (Feature) {
  Feature["AMM"] = "AMM";
  Feature["AMM_V2"] = "AMM V2";
  Feature["LIQUIDITY_MINING"] = "Liquidity Mining";
  Feature["BENTOBOX"] = "BentoBox";
  Feature["KASHI"] = "Kashi";
  Feature["MISO"] = "MISO";
  Feature["ANALYTICS"] = "Analytics";
  Feature["MIGRATE"] = "Migrate";
  Feature["STAKING"] = "Staking";
})(Feature || (Feature = {}));

const features = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS, Feature.STAKING, Feature.MISO],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: [Feature.AMM, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: [Feature.AMM, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: [Feature.AMM, Feature.LIQUIDITY_MINING],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.ANALYTICS, Feature.BENTOBOX, Feature.KASHI]
};
function featureEnabled(feature, chainId) {
  var _features$chainId;

  return features === null || features === void 0 ? void 0 : (_features$chainId = features[chainId]) === null || _features$chainId === void 0 ? void 0 : _features$chainId.includes(feature);
}
function chainsWithFeature(feature) {
  return Object.keys(features).filter(chain => features[chain].includes(feature)).map(chain => _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId[chain]);
}

/***/ })

};
;