"use strict";
exports.id = 2170;
exports.ids = [2170];
exports.modules = {

/***/ 8561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dots)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3289);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);





function Dots({
  children = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
  className
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_1___default()), {
      id: "106137454",
      children: [".dots.jsx-106137454::after{content:'.';}"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
      className: "jsx-106137454" + " " + ((0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)('after:inline-block dots after:animate-ellipsis after:w-4 after:text-left', className) || ""),
      children: children
    })]
  });
}

/***/ }),

/***/ 4596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7271);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function DoubleCurrencyLogo({
  currency0,
  currency1,
  size = 16
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: "flex items-center space-x-2",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency0,
      size: size.toString() + 'px'
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency1,
      size: size.toString() + 'px'
    })]
  });
}

/***/ }),

/***/ 1567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ farm_FarmList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
// EXTERNAL MODULE: ./src/components/Dots/index.tsx
var Dots = __webpack_require__(8561);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(4025);
// EXTERNAL MODULE: ./src/components/DoubleLogo/index.tsx
var DoubleLogo = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/hooks/useApproveCallback.ts + 1 modules
var useApproveCallback = __webpack_require__(9952);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/features/farm/enum.ts
var farm_enum = __webpack_require__(3553);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/features/farm/hooks.ts
var hooks = __webpack_require__(8099);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./src/components/NumericalInput/index.tsx
var NumericalInput = __webpack_require__(6919);
// EXTERNAL MODULE: external "@ethersproject/address"
var address_ = __webpack_require__(7398);
// EXTERNAL MODULE: ./src/functions/parse.ts
var parse = __webpack_require__(7208);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: external "@lingui/react"
var external_lingui_react_ = __webpack_require__(2339);
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var src_hooks = __webpack_require__(9202);
// EXTERNAL MODULE: external "@ethersproject/constants"
var constants_ = __webpack_require__(6148);
;// CONCATENATED MODULE: ./src/features/farm/useMasterChef.ts





function useMasterChef(chef) {
  const {
    account
  } = (0,src_hooks/* useActiveWeb3React */.aQ)();
  const sushi = (0,src_hooks/* useSushiContract */.Z9)();
  const contract = (0,hooks/* useChefContract */.zh)(chef); // Deposit

  const deposit = (0,external_react_.useCallback)(async (pid, amount) => {
    try {
      let tx;

      if (chef === farm_enum/* Chef.MASTERCHEF */.WJ.MASTERCHEF) {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.deposit(pid, amount));
      } else {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.deposit(pid, amount, account));
      }

      return tx;
    } catch (e) {
      console.error(e);
      return e;
    }
  }, [account, chef, contract]); // Withdraw

  const withdraw = (0,external_react_.useCallback)(async (pid, amount) => {
    try {
      let tx;

      if (chef === farm_enum/* Chef.MASTERCHEF */.WJ.MASTERCHEF) {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.withdraw(pid, amount));
      } else {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.withdraw(pid, amount, account));
      }

      return tx;
    } catch (e) {
      console.error(e);
      return e;
    }
  }, [account, chef, contract]);
  const harvest = (0,external_react_.useCallback)(async pid => {
    try {
      let tx;

      if (chef === farm_enum/* Chef.MASTERCHEF */.WJ.MASTERCHEF) {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.deposit(pid, constants_.Zero));
      } else if (chef === farm_enum/* Chef.MASTERCHEF_V2 */.WJ.MASTERCHEF_V2) {
        const pendingSushi = await (contract === null || contract === void 0 ? void 0 : contract.pendingSushi(pid, account));
        const balanceOf = await (sushi === null || sushi === void 0 ? void 0 : sushi.balanceOf(contract === null || contract === void 0 ? void 0 : contract.address)); // If MasterChefV2 doesn't have enough sushi to harvest, batch in a harvest.

        if (pendingSushi.gt(balanceOf)) {
          var _contract$interface, _contract$interface2;

          tx = await (contract === null || contract === void 0 ? void 0 : contract.batch([contract === null || contract === void 0 ? void 0 : (_contract$interface = contract.interface) === null || _contract$interface === void 0 ? void 0 : _contract$interface.encodeFunctionData('harvestFromMasterChef'), contract === null || contract === void 0 ? void 0 : (_contract$interface2 = contract.interface) === null || _contract$interface2 === void 0 ? void 0 : _contract$interface2.encodeFunctionData('harvest', [pid, account])], true));
        } else {
          tx = await (contract === null || contract === void 0 ? void 0 : contract.harvest(pid, account));
        }
      } else if (chef === farm_enum/* Chef.MINICHEF */.WJ.MINICHEF) {
        tx = await (contract === null || contract === void 0 ? void 0 : contract.harvest(pid, account));
      }

      return tx;
    } catch (e) {
      console.error(e);
      return e;
    }
  }, [account, chef, contract, sushi]);
  return {
    deposit,
    withdraw,
    harvest
  };
}
// EXTERNAL MODULE: ./src/state/wallet/hooks.ts
var wallet_hooks = __webpack_require__(2319);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var transactions_hooks = __webpack_require__(9123);
;// CONCATENATED MODULE: ./src/features/farm/FarmListItemDetails.tsx




















const FarmListItem = ({
  farm
}) => {
  var _balance$toSignifican, _formatNumber;

  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  const {
    account,
    chainId
  } = (0,useActiveWeb3React/* default */.Z)();
  const {
    0: pendingTx,
    1: setPendingTx
  } = (0,external_react_.useState)(false);
  const {
    0: depositValue,
    1: setDepositValue
  } = (0,external_react_.useState)('');
  const {
    0: withdrawValue,
    1: setWithdrawValue
  } = (0,external_react_.useState)('');
  const addTransaction = (0,transactions_hooks/* useTransactionAdder */.h7)();
  const liquidityToken = new sdk_.Token(chainId, (0,address_.getAddress)(farm.pair.id), farm.pair.type === farm_enum/* PairType.KASHI */.FJ.KASHI ? Number(farm.pair.asset.decimals) : 18, farm.pair.symbol, farm.pair.name); // User liquidity token balance

  const balance = (0,wallet_hooks/* useTokenBalance */.mM)(account, liquidityToken); // TODO: Replace these

  const amount = (0,hooks/* useUserInfo */.Pc)(farm, liquidityToken);
  const pendingSummit = (0,hooks/* usePendingSummit */.o2)(farm);
  console.log('pendingSummit:', pendingSummit, pendingSummit === null || pendingSummit === void 0 ? void 0 : pendingSummit.toFixed(18)); // const reward = usePendingReward(farm)

  const APPROVAL_ADDRESSES = {
    [farm_enum/* Chef.MASTERCHEF */.WJ.MASTERCHEF]: {
      [sdk_.ChainId.MAINNET]: sdk_.MASTERCHEF_ADDRESS[sdk_.ChainId.MAINNET],
      [sdk_.ChainId.GWFU]: sdk_.MASTERCHEF_ADDRESS[sdk_.ChainId.GWFU]
    },
    [farm_enum/* Chef.MASTERCHEF_V2 */.WJ.MASTERCHEF_V2]: {
      [sdk_.ChainId.MAINNET]: sdk_.MASTERCHEF_V2_ADDRESS[sdk_.ChainId.MAINNET]
    },
    [farm_enum/* Chef.MINICHEF */.WJ.MINICHEF]: {
      [sdk_.ChainId.MATIC]: sdk_.MINICHEF_ADDRESS[sdk_.ChainId.MATIC],
      [sdk_.ChainId.XDAI]: sdk_.MINICHEF_ADDRESS[sdk_.ChainId.XDAI],
      [sdk_.ChainId.HARMONY]: sdk_.MINICHEF_ADDRESS[sdk_.ChainId.HARMONY],
      [sdk_.ChainId.AVALANCHE]: sdk_.MINICHEF_ADDRESS[sdk_.ChainId.AVALANCHE]
    }
  };
  const typedDepositValue = (0,parse/* tryParseAmount */.e)(depositValue, liquidityToken);
  const typedWithdrawValue = (0,parse/* tryParseAmount */.e)(withdrawValue, liquidityToken);
  const [approvalState, approve] = (0,useApproveCallback/* useApproveCallback */.qL)(typedDepositValue, APPROVAL_ADDRESSES[farm.chef][chainId]);
  const {
    deposit,
    withdraw,
    harvest
  } = useMasterChef(farm.chef);
  return /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
    show: true,
    enter: "transition-opacity duration-75",
    enterFrom: "opacity-0",
    enterTo: "opacity-100",
    leave: "transition-opacity duration-150",
    leaveFrom: "opacity-100",
    leaveTo: "opacity-0",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Disclosure.Panel, {
      className: "flex flex-col w-full border-t-0 rounded rounded-t-none bg-dark-800",
      static: true,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-2 gap-4 p-4",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "col-span-2 text-center md:col-span-1",
          children: [account && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "pr-4 mb-2 text-sm text-right cursor-pointer text-secondary",
            children: [i18n._(
            /*i18n*/
            i18n._("Wallet Balance")), ": ", (0,functions/* formatNumber */.uf)((_balance$toSignifican = balance === null || balance === void 0 ? void 0 : balance.toSignificant(6)) !== null && _balance$toSignifican !== void 0 ? _balance$toSignifican : 0), " ", farm.type]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "relative flex items-center w-full mb-4",
            children: [/*#__PURE__*/jsx_runtime_.jsx(NumericalInput/* Input */.I, {
              className: "w-full p-3 pr-20 rounded bg-dark-700 focus:ring focus:ring-blue",
              value: depositValue,
              onUserInput: setDepositValue
            }), account && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "blue",
              size: "xs",
              onClick: () => {
                if (!balance.equalTo(sdk_.ZERO)) {
                  setDepositValue(balance.toFixed(liquidityToken.decimals));
                }
              },
              className: "absolute border-0 right-4 focus:ring focus:ring-blue",
              children: i18n._(
              /*i18n*/
              i18n._("MAX"))
            })]
          }), approvalState === useApproveCallback/* ApprovalState.NOT_APPROVED */.UK.NOT_APPROVED || approvalState === useApproveCallback/* ApprovalState.PENDING */.UK.PENDING ? /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            color: "blue",
            disabled: approvalState === useApproveCallback/* ApprovalState.PENDING */.UK.PENDING,
            onClick: approve,
            children: approvalState === useApproveCallback/* ApprovalState.PENDING */.UK.PENDING ? /*#__PURE__*/jsx_runtime_.jsx(Dots/* default */.Z, {
              children: "Approving "
            }) : 'Approve'
          }) : /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            color: "blue",
            disabled: pendingTx || !typedDepositValue || balance.lessThan(typedDepositValue),
            onClick: async () => {
              setPendingTx(true);

              try {
                // KMP decimals depend on asset, SLP is always 18
                const tx = await deposit(farm.id, depositValue.toBigNumber(liquidityToken === null || liquidityToken === void 0 ? void 0 : liquidityToken.decimals));
                addTransaction(tx, {
                  summary: `Deposit ${farm.pair.token0.name}/${farm.pair.token1.name}`
                });
              } catch (error) {
                console.error(error);
              }

              setPendingTx(false);
            },
            children: i18n._(
            /*i18n*/
            i18n._("Stake"))
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "col-span-2 text-center md:col-span-1",
          children: [account && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "pr-4 mb-2 text-sm text-right cursor-pointer text-secondary",
            children: [i18n._(
            /*i18n*/
            i18n._("Your Staked")), ": ", (_formatNumber = (0,functions/* formatNumber */.uf)(amount === null || amount === void 0 ? void 0 : amount.toSignificant(6))) !== null && _formatNumber !== void 0 ? _formatNumber : 0, " ", farm.type]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "relative flex items-center w-full mb-4",
            children: [/*#__PURE__*/jsx_runtime_.jsx(NumericalInput/* Input */.I, {
              className: "w-full p-3 pr-20 rounded bg-dark-700 focus:ring focus:ring-pink",
              value: withdrawValue,
              onUserInput: value => {
                setWithdrawValue(value);
              }
            }), account && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
              variant: "outlined",
              color: "pink",
              size: "xs",
              onClick: () => {
                if (!amount.equalTo(sdk_.ZERO)) {
                  setWithdrawValue(amount.toFixed(liquidityToken.decimals));
                }
              },
              className: "absolute border-0 right-4 focus:ring focus:ring-pink",
              children: i18n._(
              /*i18n*/
              i18n._("MAX"))
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            color: "pink",
            className: "border-0",
            disabled: pendingTx || !typedWithdrawValue || amount.lessThan(typedWithdrawValue),
            onClick: async () => {
              setPendingTx(true);

              try {
                // KMP decimals depend on asset, SLP is always 18
                const tx = await withdraw(farm.id, withdrawValue.toBigNumber(liquidityToken === null || liquidityToken === void 0 ? void 0 : liquidityToken.decimals));
                addTransaction(tx, {
                  summary: `Withdraw ${farm.pair.token0.name}/${farm.pair.token1.name}`
                });
              } catch (error) {
                console.error(error);
              }

              setPendingTx(false);
            },
            children: i18n._(
            /*i18n*/
            i18n._("Unstake"))
          })]
        })]
      }), pendingSummit && pendingSummit.greaterThan(sdk_.ZERO) && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "px-4 pb-4",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(Button/* default */.ZP, {
          color: "gradient",
          onClick: async () => {
            setPendingTx(true);

            try {
              const tx = await harvest(farm.id);
              addTransaction(tx, {
                summary: i18n._(
                /*i18n*/
                i18n._("Harvest {0}/{1}", {
                  0: farm.pair.token0.name,
                  1: farm.pair.token1.name
                }))
              });
            } catch (error) {
              console.error(error);
            }

            setPendingTx(false);
          },
          children: [i18n._(
          /*i18n*/
          i18n._("Harvest")), " ", `${(0,functions/* formatNumber */.uf)(pendingSummit.toFixed(18))} GWFU`]
        })
      })]
    })
  });
};

/* harmony default export */ const FarmListItemDetails = (FarmListItem);
// EXTERNAL MODULE: ./src/components/Image/index.tsx
var Image = __webpack_require__(5579);
// EXTERNAL MODULE: ./src/hooks/Tokens.ts
var Tokens = __webpack_require__(6269);
// EXTERNAL MODULE: ./src/components/CurrencyLogo/index.tsx + 1 modules
var CurrencyLogo = __webpack_require__(7271);
// EXTERNAL MODULE: ./src/state/lists/wrappedTokenInfo.ts
var wrappedTokenInfo = __webpack_require__(2045);
;// CONCATENATED MODULE: ./src/features/farm/FarmListItem.tsx




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }












const FarmListItem_FarmListItem = (_ref) => {
  var _farm$pair, _farm$pair$token, _farm$pair2, _farm$pair2$token, _farm$pair3, _farm$pair3$token;

  let {
    farm
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["farm"]);

  const token0 = (0,Tokens/* useCurrency */.U8)((farm === null || farm === void 0 ? void 0 : farm.pair.type) === farm_enum/* PairType.SINGLE */.FJ.SINGLE ? farm.pair.id : farm === null || farm === void 0 ? void 0 : (_farm$pair = farm.pair) === null || _farm$pair === void 0 ? void 0 : (_farm$pair$token = _farm$pair.token0) === null || _farm$pair$token === void 0 ? void 0 : _farm$pair$token.id);
  const token1 = (0,Tokens/* useCurrency */.U8)(farm === null || farm === void 0 ? void 0 : (_farm$pair2 = farm.pair) === null || _farm$pair2 === void 0 ? void 0 : (_farm$pair2$token = _farm$pair2.token1) === null || _farm$pair2$token === void 0 ? void 0 : _farm$pair2$token.id);
  let tokenoSymbol = farm === null || farm === void 0 ? void 0 : (_farm$pair3 = farm.pair) === null || _farm$pair3 === void 0 ? void 0 : (_farm$pair3$token = _farm$pair3.token1) === null || _farm$pair3$token === void 0 ? void 0 : _farm$pair3$token.symbol;

  if (token0 instanceof wrappedTokenInfo/* WrappedTokenInfo */.D) {
    tokenoSymbol = token0.tokenInfo.symbol;
  }

  return /*#__PURE__*/jsx_runtime_.jsx(react_.Disclosure, _objectSpread(_objectSpread({}, rest), {}, {
    children: ({
      open
    }) => {
      var _farm$pair4, _farm$pair5, _farm$pair5$token, _farm$rewards, _farm$rewards2;

      return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(react_.Disclosure.Button, {
          className: (0,functions/* classNames */.AK)(open && 'rounded-b-none', 'w-full px-4 py-6 text-left rounded cursor-pointer select-none bg-dark-900 text-primary text-sm md:text-lg'),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "grid grid-cols-4",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex col-span-2 space-x-4 md:col-span-1",
              children: [token1 && token0 && /*#__PURE__*/jsx_runtime_.jsx(DoubleLogo/* default */.Z, {
                currency0: token0,
                currency1: token1,
                size: 40
              }), farm.pair.type === farm_enum/* PairType.SINGLE */.FJ.SINGLE && /*#__PURE__*/jsx_runtime_.jsx(CurrencyLogo/* default */.Z, {
                currency: token0,
                size: '40px'
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex flex-col justify-center",
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "font-bold",
                    children: tokenoSymbol
                  }), farm.pair.type !== farm_enum/* PairType.SINGLE */.FJ.SINGLE && '/', farm.pair.type !== farm_enum/* PairType.SINGLE */.FJ.SINGLE && /*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: (farm === null || farm === void 0 ? void 0 : (_farm$pair4 = farm.pair) === null || _farm$pair4 === void 0 ? void 0 : _farm$pair4.type) === farm_enum/* PairType.KASHI */.FJ.KASHI ? 'font-thin' : 'font-bold',
                    children: farm === null || farm === void 0 ? void 0 : (_farm$pair5 = farm.pair) === null || _farm$pair5 === void 0 ? void 0 : (_farm$pair5$token = _farm$pair5.token1) === null || _farm$pair5$token === void 0 ? void 0 : _farm$pair5$token.symbol
                  })]
                })
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "flex flex-col justify-center font-bold",
              children: (0,functions/* formatNumber */.uf)(farm.tvl, true)
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex-row items-center hidden space-x-4 md:flex",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex items-center space-x-2",
                children: farm === null || farm === void 0 ? void 0 : (_farm$rewards = farm.rewards) === null || _farm$rewards === void 0 ? void 0 : _farm$rewards.map((reward, i) => /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "flex items-center",
                  children: /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
                    src: reward.icon,
                    width: "30px",
                    height: "30px",
                    className: "rounded-md",
                    layout: "fixed",
                    alt: reward.token
                  })
                }, i))
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "flex flex-col space-y-1",
                children: farm === null || farm === void 0 ? void 0 : (_farm$rewards2 = farm.rewards) === null || _farm$rewards2 === void 0 ? void 0 : _farm$rewards2.map((reward, i) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "text-xs md:text-sm whitespace-nowrap",
                  children: [(0,functions/* formatNumber */.uf)(reward.rewardPerDay), " ", reward.token, " / DAY"]
                }, i))
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-col items-end justify-center",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "font-bold text-righttext-high-emphesis",
                children: (0,functions/* formatPercent */.T3)((farm === null || farm === void 0 ? void 0 : farm.roiPerYear) * 100)
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "text-xs text-right md:text-base text-secondary",
                children: "annualized"
              })]
            })]
          })
        }), open && /*#__PURE__*/jsx_runtime_.jsx(FarmListItemDetails, {
          farm: farm
        })]
      });
    }
  }));
};

/* harmony default export */ const farm_FarmListItem = (FarmListItem_FarmListItem);
// EXTERNAL MODULE: ./src/hooks/useSortableData.ts
var useSortableData = __webpack_require__(9155);
;// CONCATENATED MODULE: ./src/features/farm/FarmList.tsx










const FarmList = ({
  farms,
  term
}) => {
  const {
    items,
    requestSort,
    sortConfig
  } = (0,useSortableData/* default */.Z)(farms);
  const {
    i18n
  } = (0,external_lingui_react_.useLingui)();
  return items ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid grid-cols-4 text-base font-bold text-blue",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center col-span-2 px-4 cursor-pointer md:col-span-1",
        onClick: () => requestSort('symbol'),
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "hover:text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Pool"))
        }), sortConfig && sortConfig.key === 'symbol' && (sortConfig.direction === 'ascending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronUpIcon */.g8U, {
          width: 12,
          height: 12
        }) || sortConfig.direction === 'descending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronDownIcon */.v4q, {
          width: 12,
          height: 12
        }))]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center px-4 cursor-pointer hover:text-high-emphesis",
        onClick: () => requestSort('tvl'),
        children: [i18n._(
        /*i18n*/
        i18n._("TVL")), sortConfig && sortConfig.key === 'tvl' && (sortConfig.direction === 'ascending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronUpIcon */.g8U, {
          width: 12,
          height: 12
        }) || sortConfig.direction === 'descending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronDownIcon */.v4q, {
          width: 12,
          height: 12
        }))]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "items-center justify-start hidden px-4 md:flex hover:text-high-emphesis",
        children: i18n._(
        /*i18n*/
        i18n._("Rewards"))
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-end px-4 cursor-pointer hover:text-high-emphesis",
        onClick: () => requestSort('roiPerYear'),
        children: [i18n._(
        /*i18n*/
        i18n._("APR")), sortConfig && sortConfig.key === 'roiPerYear' && (sortConfig.direction === 'ascending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronUpIcon */.g8U, {
          width: 12,
          height: 12
        }) || sortConfig.direction === 'descending' && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronDownIcon */.v4q, {
          width: 12,
          height: 12
        }))]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex-col space-y-4",
      children: items.map((farm, index) => /*#__PURE__*/jsx_runtime_.jsx(farm_FarmListItem, {
        farm: farm
      }, index))
    })]
  }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "w-full py-6 text-center",
    children: term ? /*#__PURE__*/jsx_runtime_.jsx("span", {
      children: "No Results."
    }) : /*#__PURE__*/jsx_runtime_.jsx(Dots/* default */.Z, {
      children: "Loading"
    })
  });
};

/* harmony default export */ const farm_FarmList = (FarmList);

/***/ }),

/***/ 2681:
/***/ ((module) => {

module.exports = JSON.parse('{"name":"SushiSwap Menu","timestamp":"2021-10-05T15:27:11.774Z","version":{"major":14,"minor":15,"patch":0},"tags":{},"logoURI":"https://raw.githubusercontent.com/sushiswap/art/master/sushi/logo-256x256.png","keywords":["sushiswap","default"],"tokens":[{"address":"0x6ceB572887FF76995F3417919d89Ed2a4aeBF66D","chainId":1969,"name":"Wrapped Bitcoin","symbol":"WBTC","decimals":18,"logoURI":"https://raw.githubusercontent.com/sushiswap/icons/master/token/btc.jpg"},{"address":"0xd9145CCE52D386f254917e481eB44e9943F39138","chainId":1969,"name":"Wrapped Ether","symbol":"WETH","decimals":18,"logoURI":"https://raw.githubusercontent.com/sushiswap/icons/master/token/eth.jpg"},{"name":"GWF","address":"0x41F6A4F5A5Eb10a8B8e84563B641BC3Dd02D5d49","symbol":"GWF","decimals":18,"chainId":1969,"logoURI":""},{"name":"Wrapped GWFU","address":"0xfbc8877fde8B6Bd8176584aE0dEA9982e1611504","symbol":"WGWFU","decimals":18,"chainId":1969,"logoURI":""}]}');

/***/ })

};
;