"use strict";
exports.id = 6945;
exports.ids = [6945];
exports.modules = {

/***/ 4596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7271);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function DoubleCurrencyLogo({
  currency0,
  currency1,
  size = 16
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: "flex items-center space-x-2",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency0,
      size: size.toString() + 'px'
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency1,
      size: size.toString() + 'px'
    })]
  });
}

/***/ }),

/***/ 3855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PoolList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var _components_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5780);
/* harmony import */ var _components_DoubleLogo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4596);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6269);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9260);










function PairListName({
  pair
}) {
  const token0 = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__/* .useCurrency */ .U8)(pair.address0);
  const token1 = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_5__/* .useCurrency */ .U8)(pair.address1);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "flex items-center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DoubleLogo__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
        currency0: token0,
        currency1: token1,
        size: 32
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "ml-3 font-bold whitespace-nowrap text-high-emphesis",
        children: pair.symbol
      })]
    })
  });
}

function Rewards({
  rewards
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "inline-flex items-center space-x-4 flex-inline",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex items-center space-x-2",
        children: rewards === null || rewards === void 0 ? void 0 : rewards.map((reward, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "flex items-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_6__.default, {
            src: reward.icon,
            width: "30px",
            height: "30px",
            className: "rounded-md",
            layout: "fixed",
            alt: reward.token
          })
        }, i))
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex flex-col space-y-1",
        children: rewards === null || rewards === void 0 ? void 0 : rewards.map((reward, i) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "text-xs md:text-sm whitespace-nowrap",
          children: [(0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(reward.rewardPerDay), " ", reward.token, " / DAY"]
        }, i))
      })]
    })
  });
}

function PoolList({
  pools
}) {
  const defaultSortBy = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => ({
    id: 'apr',
    desc: true
  }), []);
  const columns = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => [{
    Header: 'Pair',
    accessor: 'pair',
    Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PairListName, {
      pair: props.value
    }),
    disableSortBy: true,
    align: 'left'
  }, {
    Header: 'Rewards',
    accessor: 'rewards',
    Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Rewards, {
      rewards: props.value
    }),
    disableSortBy: true,
    align: 'left'
  }, {
    Header: 'Liquidity',
    accessor: 'liquidity',
    Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumberScale */ .nH)(props.value, true),
    align: 'right'
  }, {
    Header: 'APR',
    accessor: 'apr',
    Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatPercent */ .T3)(props.value),
    align: 'right'
  }], []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: pools && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      columns: columns,
      data: pools,
      defaultSortBy: defaultSortBy
    })
  });
}

/***/ }),

/***/ 9175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useFarmRewards)
/* harmony export */ });
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7398);
/* harmony import */ var _ethersproject_address__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_address__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3553);
/* harmony import */ var _features_farm_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8099);
/* harmony import */ var _services_graph__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8012);
/* harmony import */ var _useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8269);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








function useFarmRewards() {
  const {
    chainId
  } = (0,_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)();
  const positions = (0,_features_farm_hooks__WEBPACK_IMPORTED_MODULE_4__/* .usePositions */ .$J)();
  const farms = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useFarms */ .E2)();
  const farmAddresses = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(() => farms.map(farm => farm.pair), [farms]);
  const swapPairs = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useSushiPairs */ .__)({
    where: {
      id_in: farmAddresses
    }
  });
  const kashiPairs = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useKashiPairs */ .Fp)({
    where: {
      id_in: farmAddresses
    }
  });
  const averageBlockTime = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useAverageBlockTime */ .Te)();
  const masterChefV1TotalAllocPoint = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useMasterChefV1TotalAllocPoint */ .M1)();
  const masterChefV1SushiPerBlock = (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useMasterChefV1SushiPerBlock */ .av)();
  const [sushiPrice, nativePrice, maticPrice, stakePrice] = [(0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useSushiPrice */ .W)(), (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useNativePrice */ .k$)(), (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useMaticPrice */ .ME)(), (0,_services_graph__WEBPACK_IMPORTED_MODULE_5__/* .useStakePrice */ .it)()];
  const blocksPerDay = 86400 / Number(averageBlockTime);

  const map = pool => {
    // TODO: Account for fees generated in case of swap pairs, and use standard compounding
    // algorithm with the same intervals acrosss chains to account for consistency.
    // For lending pairs, what should the equivilent for fees generated? Interest gained?
    // How can we include this?
    // TODO: Deal with inconsistencies between properties on subgraph
    pool.owner = (pool === null || pool === void 0 ? void 0 : pool.owner) || (pool === null || pool === void 0 ? void 0 : pool.masterChef) || (pool === null || pool === void 0 ? void 0 : pool.miniChef);
    pool.balance = (pool === null || pool === void 0 ? void 0 : pool.balance) || (pool === null || pool === void 0 ? void 0 : pool.slpBalance);
    const swapPair = swapPairs === null || swapPairs === void 0 ? void 0 : swapPairs.find(pair => pair.id === pool.pair);
    const kashiPair = kashiPairs === null || kashiPairs === void 0 ? void 0 : kashiPairs.find(pair => pair.id === pool.pair);
    const type = swapPair ? _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__/* .PairType.SWAP */ .FJ.SWAP : _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__/* .PairType.KASHI */ .FJ.KASHI;
    const pair = swapPair || kashiPair;
    const blocksPerHour = 3600 / averageBlockTime;

    function getRewards() {
      var _pool$owner, _pool$owner2;

      // TODO: Some subgraphs give sushiPerBlock & sushiPerSecond, and mcv2 gives nothing
      const sushiPerBlock = (pool === null || pool === void 0 ? void 0 : (_pool$owner = pool.owner) === null || _pool$owner === void 0 ? void 0 : _pool$owner.sushiPerBlock) / 1e18 || (pool === null || pool === void 0 ? void 0 : (_pool$owner2 = pool.owner) === null || _pool$owner2 === void 0 ? void 0 : _pool$owner2.sushiPerSecond) / 1e18 * averageBlockTime || masterChefV1SushiPerBlock;
      const rewardPerBlock = pool.allocPoint / pool.owner.totalAllocPoint * sushiPerBlock;
      const defaultReward = {
        token: 'SUSHI',
        icon: 'https://raw.githubusercontent.com/sushiswap/icons/master/token/sushi.jpg',
        rewardPerBlock,
        rewardPerDay: rewardPerBlock * blocksPerDay,
        rewardPrice: sushiPrice
      };
      const defaultRewards = [defaultReward];

      if (pool.chef === _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__/* .Chef.MASTERCHEF_V2 */ .WJ.MASTERCHEF_V2) {
        // override for mcv2...
        pool.owner.totalAllocPoint = masterChefV1TotalAllocPoint;
        const icon = ['0', '3', '4', '8'].includes(pool.id) ? `https://raw.githubusercontent.com/sushiswap/icons/master/token/${pool.rewardToken.symbol.toLowerCase()}.jpg` : `https://raw.githubusercontent.com/sushiswap/assets/master/blockchains/ethereum/assets/${(0,_ethersproject_address__WEBPACK_IMPORTED_MODULE_0__.getAddress)(pool.rewarder.rewardToken)}/logo.png`;
        const decimals = 10 ** pool.rewardToken.decimals;
        const rewardPerBlock = pool.rewardToken.symbol === 'ALCX' ? pool.rewarder.rewardPerSecond / decimals : pool.rewarder.rewardPerSecond / decimals * averageBlockTime;
        const rewardPerDay = pool.rewardToken.symbol === 'ALCX' ? pool.rewarder.rewardPerSecond / decimals * blocksPerDay : pool.rewarder.rewardPerSecond / decimals * averageBlockTime * blocksPerDay;
        const reward = {
          token: pool.rewardToken.symbol,
          icon: icon,
          rewardPerBlock: rewardPerBlock,
          rewardPerDay: rewardPerDay,
          rewardPrice: pool.rewardToken.derivedETH * nativePrice
        };
        return [...defaultRewards, reward];
      } else if (pool.chef === _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__/* .Chef.MINICHEF */ .WJ.MINICHEF) {
        const sushiPerSecond = pool.allocPoint / pool.miniChef.totalAllocPoint * pool.miniChef.sushiPerSecond / 1e18;
        const sushiPerBlock = sushiPerSecond * averageBlockTime;
        const sushiPerDay = sushiPerBlock * blocksPerDay;
        const rewardPerSecond = pool.allocPoint / pool.miniChef.totalAllocPoint * pool.rewarder.rewardPerSecond / 1e18;
        const rewardPerBlock = rewardPerSecond * averageBlockTime;
        const rewardPerDay = rewardPerBlock * blocksPerDay;
        const reward = {
          [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.MATIC]: {
            token: 'MATIC',
            icon: 'https://raw.githubusercontent.com/sushiswap/icons/master/token/polygon.jpg',
            rewardPrice: maticPrice
          },
          [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.XDAI]: {
            token: 'STAKE',
            icon: 'https://raw.githubusercontent.com/sushiswap/icons/master/token/stake.jpg',
            rewardPrice: stakePrice
          },
          [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.ChainId.HARMONY]: {
            token: 'ONE',
            icon: 'https://raw.githubusercontent.com/sushiswap/icons/master/token/one.jpg',
            rewardPrice: nativePrice // Reward token = Native token

          }
        };
        return [_objectSpread(_objectSpread({}, defaultReward), {}, {
          rewardPerBlock: sushiPerBlock,
          rewardPerDay: sushiPerDay
        }), _objectSpread(_objectSpread({}, reward[chainId]), {}, {
          rewardPerBlock: rewardPerBlock,
          rewardPerDay: rewardPerDay
        })];
      }

      return defaultRewards;
    }

    const rewards = getRewards();
    const balance = swapPair ? Number(pool.balance / 1e18) : pool.balance / 10 ** kashiPair.token0.decimals;
    const tvl = swapPair ? balance / Number(swapPair.totalSupply) * Number(swapPair.reserveUSD) : balance * kashiPair.token0.derivedETH * nativePrice;
    const roiPerBlock = rewards.reduce((previousValue, currentValue) => {
      return previousValue + currentValue.rewardPerBlock * currentValue.rewardPrice;
    }, 0) / tvl;
    const roiPerHour = roiPerBlock * blocksPerHour;
    const roiPerDay = roiPerHour * 24;
    const roiPerMonth = roiPerDay * 30;
    const roiPerYear = roiPerMonth * 12;
    const position = positions.find(position => position.id === pool.id && position.chef === pool.chef);
    return _objectSpread(_objectSpread(_objectSpread({}, pool), position), {}, {
      pair: _objectSpread(_objectSpread({}, pair), {}, {
        decimals: pair.type === _features_farm_enum__WEBPACK_IMPORTED_MODULE_3__/* .PairType.KASHI */ .FJ.KASHI ? Number(pair.asset.tokenInfo.decimals) : 18,
        type
      }),
      balance,
      roiPerBlock,
      roiPerHour,
      roiPerDay,
      roiPerMonth,
      roiPerYear,
      rewards,
      tvl
    });
  };

  return farms.filter(farm => {
    return swapPairs && swapPairs.find(pair => pair.id === farm.pair) || kashiPairs && kashiPairs.find(pair => pair.id === farm.pair);
  }).map(map);
}

/***/ })

};
;