"use strict";
exports.id = 8099;
exports.ids = [8099];
exports.modules = {

/***/ 8099:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "zh": () => (/* binding */ useChefContract),
/* harmony export */   "Pc": () => (/* binding */ useUserInfo),
/* harmony export */   "o2": () => (/* binding */ usePendingSummit),
/* harmony export */   "$J": () => (/* binding */ usePositions)
/* harmony export */ });
/* unused harmony exports useChefContracts, usePendingSushi, usePendingToken, useChefPositions */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3553);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(879);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useContract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1263);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8532);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6148);
/* harmony import */ var _ethersproject_constants__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_constants__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var lodash_concat__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7508);
/* harmony import */ var lodash_concat__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_concat__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8269);
/* harmony import */ var lodash_zip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6643);
/* harmony import */ var lodash_zip__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_zip__WEBPACK_IMPORTED_MODULE_9__);










function useChefContract(chef) {
  const masterChefContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMasterChefContract */ .mi)();
  const masterChefV2Contract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMasterChefV2Contract */ .sd)();
  const miniChefContract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMiniChefContract */ .U$)();
  const contracts = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => ({
    [_enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF */ .WJ.MASTERCHEF]: masterChefContract,
    [_enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF_V2 */ .WJ.MASTERCHEF_V2]: masterChefV2Contract,
    [_enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MINICHEF */ .WJ.MINICHEF]: miniChefContract
  }), [masterChefContract, masterChefV2Contract, miniChefContract]);
  return (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    return contracts[chef];
  }, [contracts, chef]);
}
const CHEFS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [_enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF */ .WJ.MASTERCHEF, _enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF_V2 */ .WJ.MASTERCHEF_V2],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: [_enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MINICHEF */ .WJ.MINICHEF]
};
function useChefContracts(chefs) {
  const masterChefContract = useMasterChefContract();
  const masterChefV2Contract = useMasterChefV2Contract();
  const miniChefContract = useMiniChefContract();
  const contracts = useMemo(() => ({
    [Chef.MASTERCHEF]: masterChefContract,
    [Chef.MASTERCHEF_V2]: masterChefV2Contract,
    [Chef.MINICHEF]: miniChefContract
  }), [masterChefContract, masterChefV2Contract, miniChefContract]);
  return chefs.map(chef => contracts[chef]);
}
function useUserInfo(farm, token) {
  var _useSingleCallResult;

  const {
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .a)();
  const contract = useChefContract(farm.chef);
  const args = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    if (!account) {
      return;
    }

    return [String(farm.id), String(account)];
  }, [farm, account]);
  const result = (_useSingleCallResult = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(args ? contract : null, 'userInfo', args)) === null || _useSingleCallResult === void 0 ? void 0 : _useSingleCallResult.result;
  const value = result === null || result === void 0 ? void 0 : result[0];
  const amount = value ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()) : undefined;
  return amount ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(token, amount) : undefined;
}
function usePendingSummit(farm) {
  var _useSingleCallResult2;

  const {
    account,
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .a)();
  const contract = (0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMasterChefContract */ .mi)();
  const args = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    if (!account) {
      return;
    }

    return [String(farm.id), String(account)];
  }, [farm, account]);
  const result = (_useSingleCallResult2 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(args ? contract : null, 'pendingReward', args)) === null || _useSingleCallResult2 === void 0 ? void 0 : _useSingleCallResult2.result;
  const value = result === null || result === void 0 ? void 0 : result[0];
  const amount = value ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.JSBI.BigInt(value.toString()) : undefined;
  return amount ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(_constants__WEBPACK_IMPORTED_MODULE_5__/* .WGWFU */ .Sf[chainId], amount) : undefined;
}
function usePendingSushi(farm) {
  var _useSingleCallResult3;

  const {
    account,
    chainId
  } = useActiveWeb3React();
  const contract = useChefContract(farm.chef);
  const args = useMemo(() => {
    if (!account) {
      return;
    }

    return [String(farm.id), String(account)];
  }, [farm, account]);
  const result = (_useSingleCallResult3 = useSingleCallResult(args ? contract : null, 'pendingReward', args)) === null || _useSingleCallResult3 === void 0 ? void 0 : _useSingleCallResult3.result;
  const value = result === null || result === void 0 ? void 0 : result[0];
  const amount = value ? JSBI.BigInt(value.toString()) : undefined;
  return amount ? CurrencyAmount.fromRawAmount(SUSHI[chainId], amount) : undefined;
}
function usePendingToken(farm, contract) {
  const {
    account
  } = useActiveWeb3React();
  const args = useMemo(() => {
    if (!account || !farm) {
      return;
    }

    return [String(farm.pid), String(account)];
  }, [farm, account]);
  const pendingTokens = useSingleContractMultipleData(args ? contract : null, 'pendingTokens', args.map(arg => [...arg, '0']));
  return useMemo(() => pendingTokens, [pendingTokens]);
}
function useChefPositions(contract, rewarder, chainId = undefined) {
  var _useSingleCallResult4, _useSingleCallResult5;

  const {
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_8__/* .useActiveWeb3React */ .a)();
  const numberOfPools = (_useSingleCallResult4 = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleCallResult */ .Wk)(contract ? contract : null, 'poolLength', undefined, _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .NEVER_RELOAD */ .DB)) === null || _useSingleCallResult4 === void 0 ? void 0 : (_useSingleCallResult5 = _useSingleCallResult4.result) === null || _useSingleCallResult5 === void 0 ? void 0 : _useSingleCallResult5[0];
  const args = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    if (!account || !numberOfPools) {
      return;
    }

    return [...Array(numberOfPools.toNumber()).keys()].map(pid => [String(pid), String(account)]);
  }, [numberOfPools, account]);
  const pendingSushi = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleContractMultipleData */ .es)(args ? contract : null, 'pendingReward', args);
  const userInfo = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useSingleContractMultipleData */ .es)(args ? contract : null, 'userInfo', args); // const pendingTokens = useSingleContractMultipleData(
  //     rewarder,
  //     'pendingTokens',
  //     args.map((arg) => [...arg, '0'])
  // )

  const getChef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(() => {
    if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.MASTERCHEF_ADDRESS[chainId] === contract.address) {
      return _enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF */ .WJ.MASTERCHEF;
    } else if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.MASTERCHEF_V2_ADDRESS[chainId] === contract.address) {
      return _enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MASTERCHEF_V2 */ .WJ.MASTERCHEF_V2;
    } else if (_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.MINICHEF_ADDRESS[chainId] === contract.address) {
      return _enum__WEBPACK_IMPORTED_MODULE_1__/* .Chef.MINICHEF */ .WJ.MINICHEF;
    }
  }, [chainId, contract]);
  return (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(() => {
    if (!pendingSushi || !userInfo) {
      return [];
    }

    return lodash_zip__WEBPACK_IMPORTED_MODULE_9___default()(pendingSushi, userInfo).map((data, i) => {
      var _data$0$result, _data$1$result;

      return {
        id: args[i][0],
        pendingSushi: ((_data$0$result = data[0].result) === null || _data$0$result === void 0 ? void 0 : _data$0$result[0]) || _ethersproject_constants__WEBPACK_IMPORTED_MODULE_6__.Zero,
        amount: ((_data$1$result = data[1].result) === null || _data$1$result === void 0 ? void 0 : _data$1$result[0]) || _ethersproject_constants__WEBPACK_IMPORTED_MODULE_6__.Zero,
        chef: getChef() // pendingTokens: data?.[2]?.result,

      };
    }).filter(({
      pendingSushi,
      amount
    }) => {
      return pendingSushi && !pendingSushi.isZero() || amount && !amount.isZero();
    });
  }, [args, getChef, pendingSushi, userInfo]);
}
function usePositions(chainId = undefined) {
  const [masterChefV1Positions] = [useChefPositions((0,_hooks_useContract__WEBPACK_IMPORTED_MODULE_4__/* .useMasterChefContract */ .mi)(), undefined, chainId)];
  return lodash_concat__WEBPACK_IMPORTED_MODULE_7___default()(masterChefV1Positions);
}

/***/ })

};
;