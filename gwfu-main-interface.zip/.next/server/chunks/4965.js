"use strict";
exports.id = 4965;
exports.ids = [4965];
exports.modules = {

/***/ 4965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ NETWORK_ICON),
/* harmony export */   "z": () => (/* binding */ NETWORK_LABEL)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

const Arbitrum = '/images/networks/arbitrum-network.jpg';
const Avalanche = '/images/networks/avalanche-network.jpg';
const Bsc = '/images/networks/bsc-network.jpg';
const Fantom = '/images/networks/fantom-network.jpg';
const Goerli = '/images/networks/goerli-network.jpg';
const Harmony = '/images/networks/harmonyone-network.jpg';
const Heco = '/images/networks/heco-network.jpg';
const Kovan = '/images/networks/kovan-network.jpg';
const Mainnet = '/images/networks/mainnet-network.jpg';
const Matic = '/images/networks/matic-network.jpg';
const Moonbeam = '/images/networks/moonbeam-network.jpg';
const OKEx = '/images/networks/okex-network.jpg';
const Polygon = '/images/networks/polygon-network.jpg';
const Rinkeby = '/images/networks/rinkeby-network.jpg';
const Ropsten = '/images/networks/ropsten-network.jpg';
const xDai = '/images/networks/xdai-network.jpg';
const Celo = '/images/networks/celo-network.jpg';
const GWFU = '/images/networks/gwfu.png';
const Palm = 'https://raw.githubusercontent.com/sushiswap/icons/master/network/palm.jpg';
const NETWORK_ICON = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: Mainnet,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: Ropsten,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: Rinkeby,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: Goerli,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: Kovan,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: Fantom,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: Fantom,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: Bsc,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: Bsc,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: Polygon,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: Matic,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: xDai,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: Arbitrum,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: Arbitrum,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: Moonbeam,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: Avalanche,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: Avalanche,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: Heco,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: Heco,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: Harmony,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: Harmony,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: OKEx,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: OKEx,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: Celo,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM]: Palm,
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.GWFU]: GWFU
};
const NETWORK_LABEL = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: 'Ethereum',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: 'Rinkeby',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: 'Ropsten',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: 'Görli',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: 'Kovan',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: 'Fantom',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: 'Fantom Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: 'Polygon (Matic)',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: 'Matic Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: 'xDai',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: 'Arbitrum',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM_TESTNET]: 'Arbitrum Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: 'BSC',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: 'BSC Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: 'Moonbase',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: 'Avalanche',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: 'Fuji',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: 'HECO',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: 'HECO Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: 'Harmony',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: 'Harmony Testnet',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: 'OKEx',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: 'OKEx',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: 'Celo',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM]: 'Palm',
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.GWFU]: 'GWFU'
};

/***/ })

};
;