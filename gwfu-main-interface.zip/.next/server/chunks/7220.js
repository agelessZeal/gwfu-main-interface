"use strict";
exports.id = 7220;
exports.ids = [7220,6820];
exports.modules = {

/***/ 5696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports COLOR, SIZE */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const COLOR = {
  default: '',
  blue: 'bg-blue bg-opacity-20 outline-blue rounded text-xs text-blue px-2 py-1',
  pink: 'bg-pink bg-opacity-20 outline-pink rounded text-xs text-pink px-2 py-1',
  gradient: 'bg-gradient-to-r from-blue to-pink opacity-80 hover:opacity-100 bg-pink bg-opacity-20 outline-pink rounded text-base text-white px-2 py-1'
};
const SIZE = {
  default: 'text-xs',
  medium: 'text-sm',
  large: 'text-lg'
};

function Badge({
  color = 'default',
  size = 'default',
  children,
  className = ''
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: `${COLOR[color]} ${SIZE[size]} ${className}`,
    children: children
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Badge);

/***/ }),

/***/ 9885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9337);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_1__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const CloseIcon = props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_feather__WEBPACK_IMPORTED_MODULE_1__.X, _objectSpread({
  className: "cursor-pointer"
}, props));

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CloseIcon);

/***/ }),

/***/ 2533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CurrencyInputPanel)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
// EXTERNAL MODULE: ./src/components/CurrencyLogo/index.tsx + 1 modules
var CurrencyLogo = __webpack_require__(7271);
// EXTERNAL MODULE: ./src/modals/SearchModal/CurrencySearchModal.tsx + 14 modules
var CurrencySearchModal = __webpack_require__(6091);
// EXTERNAL MODULE: ./src/components/DoubleLogo/index.tsx
var DoubleLogo = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/functions/prices.ts
var prices = __webpack_require__(1545);
;// CONCATENATED MODULE: ./src/components/CurrencyInputPanel/FiatValue.tsx





function FiatValue({
  fiatValue,
  priceImpact
}) {
  const priceImpactClassName = (0,external_react_.useMemo)(() => {
    if (!priceImpact) return undefined;
    if (priceImpact.lessThan('0')) return 'text-green';
    const severity = (0,prices/* warningSeverity */.oX)(priceImpact);
    if (severity < 1) return 'text-secondary';
    if (severity < 3) return 'text-yellow';
    return 'text-red';
  }, [priceImpact]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex justify-end space-x-1 text-xs font-medium text-right text-secondary",
    children: [fiatValue ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: ["\u2248$ ", /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "cursor-pointer",
        children: fiatValue === null || fiatValue === void 0 ? void 0 : fiatValue.toSignificant(6, {
          groupSeparator: ','
        })
      })]
    }) : '', priceImpact ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
      className: priceImpactClassName,
      children: [priceImpact.multiply(-1).toSignificant(3), "%"]
    }) : null]
  });
}
// EXTERNAL MODULE: external "lottie-react"
var external_lottie_react_ = __webpack_require__(2409);
var external_lottie_react_default = /*#__PURE__*/__webpack_require__.n(external_lottie_react_);
// EXTERNAL MODULE: ./src/components/NumericalInput/index.tsx
var NumericalInput = __webpack_require__(6919);
// EXTERNAL MODULE: ./src/animation/select-coin.json
var select_coin = __webpack_require__(134);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/state/wallet/hooks.ts
var hooks = __webpack_require__(2319);
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/CurrencyInputPanel/index.tsx

















function CurrencyInputPanel({
  value,
  onUserInput,
  onMax,
  showMaxButton,
  label = 'Input',
  onCurrencySelect,
  currency,
  disableCurrencySelect = false,
  otherCurrency,
  id,
  showCommonBases,
  renderBalance,
  fiatValue,
  priceImpact,
  hideBalance = false,
  pair = null,
  // used for double token logo
  hideInput = false,
  locked = false,
  customBalanceText
}) {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    0: modalOpen,
    1: setModalOpen
  } = (0,external_react_.useState)(false);
  const {
    account
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const selectedCurrencyBalance = (0,hooks/* useCurrencyBalance */._h)(account !== null && account !== void 0 ? account : undefined, currency !== null && currency !== void 0 ? currency : undefined);
  const handleDismissSearch = (0,external_react_.useCallback)(() => {
    setModalOpen(false);
  }, [setModalOpen]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    id: id,
    className: (0,functions/* classNames */.AK)(hideInput ? 'p-4' : 'p-5', 'rounded bg-dark-800'),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col justify-between space-y-3 sm:space-y-0 sm:flex-row",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (0,functions/* classNames */.AK)('w-full sm:w-2/5'),
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "button",
          className: (0,functions/* classNames */.AK)(!!currency ? 'text-primary' : 'text-high-emphesis', 'open-currency-select-button h-full outline-none select-none cursor-pointer border-none text-xl font-medium items-center'),
          onClick: () => {
            if (onCurrencySelect) {
              setModalOpen(true);
            }
          },
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex",
            children: [pair ? /*#__PURE__*/jsx_runtime_.jsx(DoubleLogo/* default */.Z, {
              currency0: pair.token0,
              currency1: pair.token1,
              size: 54,
              margin: true
            }) : currency ? /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "flex items-center",
              children: /*#__PURE__*/jsx_runtime_.jsx(CurrencyLogo/* default */.Z, {
                currency: currency,
                size: '54px'
              })
            }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "rounded bg-dark-700",
              style: {
                maxWidth: 54,
                maxHeight: 54
              },
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                style: {
                  width: 54,
                  height: 54
                },
                children: /*#__PURE__*/jsx_runtime_.jsx((external_lottie_react_default()), {
                  animationData: select_coin,
                  autoplay: true,
                  loop: true
                })
              })
            }), pair ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: (0,functions/* classNames */.AK)('pair-name-container', Boolean(currency && currency.symbol) ? 'text-2xl' : 'text-xs'),
              children: [pair === null || pair === void 0 ? void 0 : pair.token0.symbol, ":", pair === null || pair === void 0 ? void 0 : pair.token1.symbol]
            }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex flex-1 flex-col items-start justify-center mx-3.5",
              children: [label && /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "text-xs font-medium text-secondary whitespace-nowrap",
                children: label
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center",
                children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "text-lg font-bold token-symbol-container md:text-2xl",
                  children: (currency && currency.symbol && currency.symbol.length > 20 ? currency.symbol.slice(0, 4) + '...' + currency.symbol.slice(currency.symbol.length - 5, currency.symbol.length) : currency === null || currency === void 0 ? void 0 : currency.symbol) || /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "px-2 py-1 mt-1 text-xs font-medium bg-transparent border rounded-full hover:bg-primary border-low-emphesis text-secondary whitespace-nowrap ",
                    children: i18n._(
                    /*i18n*/
                    i18n._("Select a token"))
                  })
                }), !disableCurrencySelect && currency && /*#__PURE__*/jsx_runtime_.jsx(esm/* ChevronDownIcon */.v4q, {
                  width: 16,
                  height: 16,
                  className: "ml-2 stroke-current"
                })]
              })]
            })]
          })
        })
      }), !hideInput && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (0,functions/* classNames */.AK)('flex items-center w-full space-x-3 rounded bg-dark-900 focus:bg-dark-700 p-3 sm:w-3/5' // showMaxButton && selectedCurrencyBalance && 'px-3'
        ),
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [showMaxButton && selectedCurrencyBalance && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
            onClick: onMax,
            size: "xs",
            className: "text-xs font-medium bg-transparent border rounded-full hover:bg-primary border-low-emphesis text-secondary whitespace-nowrap",
            children: i18n._(
            /*i18n*/
            i18n._("Max"))
          }), /*#__PURE__*/jsx_runtime_.jsx(NumericalInput/* Input */.I, {
            id: "token-amount-input",
            value: value,
            onUserInput: val => {
              onUserInput(val);
            }
          }), !hideBalance && currency && selectedCurrencyBalance ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              onClick: onMax,
              className: "text-xs font-medium text-right cursor-pointer text-low-emphesis",
              children: renderBalance ? renderBalance(selectedCurrencyBalance) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [i18n._(
                /*i18n*/
                i18n._("Balance:")), " ", (0,functions/* formatCurrencyAmount */.ZO)(selectedCurrencyBalance, 4), " ", currency.symbol]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(FiatValue, {
              fiatValue: fiatValue,
              priceImpact: priceImpact
            })]
          }) : null]
        })
      })]
    }), !disableCurrencySelect && onCurrencySelect && /*#__PURE__*/jsx_runtime_.jsx(CurrencySearchModal/* default */.Z, {
      isOpen: modalOpen,
      onDismiss: handleDismissSearch,
      onCurrencySelect: onCurrencySelect,
      selectedCurrency: currency,
      otherSelectedCurrency: otherCurrency,
      showCommonBases: showCommonBases
    })]
  });
}

/***/ }),

/***/ 4228:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2047);
/* harmony import */ var react_device_detect__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_device_detect__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);




const DoubleGlowShadow = ({
  children,
  className
}) => {
  if (react_device_detect__WEBPACK_IMPORTED_MODULE_1__.isMobile) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "shadow-swap",
      children: children
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)(className, 'relative w-full max-w-2xl'),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "relative filter drop-shadow",
      children: children
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DoubleGlowShadow);

/***/ }),

/***/ 4596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7271);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function DoubleCurrencyLogo({
  currency0,
  currency1,
  size = 16
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: "flex items-center space-x-2",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency0,
      size: size.toString() + 'px'
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      currency: currency1,
      size: size.toString() + 'px'
    })]
  });
}

/***/ }),

/***/ 5000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_ExchangeHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__(7749);
var external_swr_default = /*#__PURE__*/__webpack_require__.n(external_swr_);
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/components/Gas/index.tsx





function Gas() {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    data,
    error
  } = external_swr_default()('https://ethgasstation.info/api/ethgasAPI.json?', url => fetch(url).then(r => r.json()));
  if (error) return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: i18n._(
    /*i18n*/
    i18n._("failed to load"))
  });
  if (!data) return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: i18n._(
    /*i18n*/
    i18n._("loading..."))
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    children: data.average / 10
  });
}

/* harmony default export */ const components_Gas = (Gas);
// EXTERNAL MODULE: ./src/components/NavLink/index.tsx
var NavLink = __webpack_require__(3233);
// EXTERNAL MODULE: ./src/state/user/hooks.tsx
var hooks = __webpack_require__(181);
// EXTERNAL MODULE: ./src/state/application/hooks.ts
var application_hooks = __webpack_require__(4663);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(6049);
// EXTERNAL MODULE: ./src/state/application/actions.ts
var actions = __webpack_require__(434);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(1441);
// EXTERNAL MODULE: ./src/components/ModalHeader/index.tsx
var ModalHeader = __webpack_require__(7144);
// EXTERNAL MODULE: ./src/components/QuestionHelper/index.tsx
var QuestionHelper = __webpack_require__(5068);
// EXTERNAL MODULE: external "@headlessui/react"
var external_headlessui_react_ = __webpack_require__(4025);
// EXTERNAL MODULE: ./src/functions/index.ts
var functions = __webpack_require__(7735);
;// CONCATENATED MODULE: ./src/components/Toggle/index.tsx





function Toggle({
  id,
  isActive,
  toggle
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_headlessui_react_.Switch, {
    checked: isActive,
    onChange: toggle,
    className: (0,functions/* classNames */.AK)(isActive ? 'bg-blue' : 'bg-dark-800', 'relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none'),
    children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "sr-only",
      children: "Use setting"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
      className: (0,functions/* classNames */.AK)(isActive ? 'translate-x-5' : 'translate-x-0', 'pointer-events-none relative inline-block h-5 w-5 rounded-full bg-dark-900 shadow transform ring-0 transition ease-in-out duration-200'),
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (0,functions/* classNames */.AK)(isActive ? 'opacity-0 ease-out duration-100' : 'opacity-100 ease-in duration-200', 'absolute inset-0 h-full w-full flex items-center justify-center transition-opacity'),
        "aria-hidden": "true",
        children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
          className: "w-3 h-3 text-low-emphesis",
          fill: "none",
          viewBox: "0 0 12 12",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            d: "M4 8l2-2m0 0l2-2M6 6L4 4m2 2l2 2",
            stroke: "currentColor",
            strokeWidth: 2,
            strokeLinecap: "round",
            strokeLinejoin: "round"
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: (0,functions/* classNames */.AK)(isActive ? 'opacity-100 ease-in duration-200' : 'opacity-0 ease-out duration-100', 'absolute inset-0 h-full w-full flex items-center justify-center transition-opacity'),
        "aria-hidden": "true",
        children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
          className: "w-3 h-3 text-high-emphesis",
          fill: "currentColor",
          viewBox: "0 0 12 12",
          children: /*#__PURE__*/jsx_runtime_.jsx("path", {
            d: "M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z"
          })
        })
      })]
    })]
  });
}
// EXTERNAL MODULE: ./src/constants/index.ts
var constants = __webpack_require__(8532);
// EXTERNAL MODULE: ./src/components/Typography/index.tsx
var Typography = __webpack_require__(3130);
;// CONCATENATED MODULE: ./src/components/TransactionSettings/index.tsx











var SlippageError;

(function (SlippageError) {
  SlippageError["InvalidInput"] = "InvalidInput";
  SlippageError["RiskyLow"] = "RiskyLow";
  SlippageError["RiskyHigh"] = "RiskyHigh";
})(SlippageError || (SlippageError = {}));

var DeadlineError;

(function (DeadlineError) {
  DeadlineError["InvalidInput"] = "InvalidInput";
})(DeadlineError || (DeadlineError = {}));

function TransactionSettings({
  placeholderSlippage
}) {
  const {
    i18n
  } = (0,react_.useLingui)();
  const inputRef = (0,external_react_.useRef)();
  const userSlippageTolerance = (0,hooks/* useUserSlippageTolerance */.$2)();
  const setUserSlippageTolerance = (0,hooks/* useSetUserSlippageTolerance */.Ow)();
  const [deadline, setDeadline] = (0,hooks/* useUserTransactionTTL */.A6)();
  const {
    0: slippageInput,
    1: setSlippageInput
  } = (0,external_react_.useState)('');
  const {
    0: slippageError,
    1: setSlippageError
  } = (0,external_react_.useState)(false);
  const {
    0: deadlineInput,
    1: setDeadlineInput
  } = (0,external_react_.useState)('');
  const {
    0: deadlineError,
    1: setDeadlineError
  } = (0,external_react_.useState)(false);

  function parseSlippageInput(value) {
    // populate what the user typed and clear the error
    setSlippageInput(value);
    setSlippageError(false);

    if (value.length === 0) {
      setUserSlippageTolerance('auto');
    } else {
      const parsed = Math.floor(Number.parseFloat(value) * 100);

      if (!Number.isInteger(parsed) || parsed < 0 || parsed > 5000) {
        setUserSlippageTolerance('auto');

        if (value !== '.') {
          setSlippageError(SlippageError.InvalidInput);
        }
      } else {
        setUserSlippageTolerance(new sdk_.Percent(parsed, 10000));
      }
    }
  }

  const tooLow = userSlippageTolerance !== 'auto' && userSlippageTolerance.lessThan(new sdk_.Percent(5, 10000));
  const tooHigh = userSlippageTolerance !== 'auto' && userSlippageTolerance.greaterThan(new sdk_.Percent(1, 100));

  function parseCustomDeadline(value) {
    // populate what the user typed and clear the error
    setDeadlineInput(value);
    setDeadlineError(false);

    if (value.length === 0) {
      setDeadline(constants/* DEFAULT_DEADLINE_FROM_NOW */.PY);
    } else {
      try {
        const parsed = Math.floor(Number.parseFloat(value) * 60);

        if (!Number.isInteger(parsed) || parsed < 60 || parsed > 180 * 60) {
          setDeadlineError(DeadlineError.InvalidInput);
        } else {
          setDeadline(parsed);
        }
      } catch (error) {
        console.error(error);
        setDeadlineError(DeadlineError.InvalidInput);
      }
    }
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "grid gap-4",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid gap-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "sm",
          className: "text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Slippage tolerance"))
        }), /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
          text: i18n._(
          /*i18n*/
          i18n._("Your transaction will revert 23if the price changes unfavorably by more than this percentage."))
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center space-x-2",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (0,functions/* classNames */.AK)(!!slippageError ? 'border-red' : tooLow || tooHigh ? 'border-yellow' : userSlippageTolerance !== 'auto' ? 'border-blue' : 'border-transparent', 'border p-2 rounded bg-dark-800'),
          tabIndex: -1,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center justify-between gap-1",
            children: [tooLow || tooHigh ? /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "hidden sm:inline text-yellow",
              role: "img",
              "aria-label": "warning",
              children: "\u26A0\uFE0F"
            }) : null, /*#__PURE__*/jsx_runtime_.jsx("input", {
              className: (0,functions/* classNames */.AK)(slippageError ? 'text-red' : '', 'bg-transparent placeholder-low-emphesis'),
              placeholder: placeholderSlippage === null || placeholderSlippage === void 0 ? void 0 : placeholderSlippage.toFixed(2),
              value: slippageInput.length > 0 ? slippageInput : userSlippageTolerance === 'auto' ? '' : userSlippageTolerance.toFixed(2),
              onChange: e => parseSlippageInput(e.target.value),
              onBlur: () => {
                setSlippageInput('');
                setSlippageError(false);
              },
              color: slippageError ? 'red' : ''
            }), "%"]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          size: "sm",
          color: userSlippageTolerance === 'auto' ? 'blue' : 'gray',
          variant: userSlippageTolerance === 'auto' ? 'filled' : 'outlined',
          onClick: () => {
            parseSlippageInput('');
          },
          children: i18n._(
          /*i18n*/
          i18n._("Auto"))
        })]
      }), slippageError || tooLow || tooHigh ? /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
        className: (0,functions/* classNames */.AK)(slippageError === SlippageError.InvalidInput ? 'text-red' : 'text-yellow', 'font-medium flex items-center space-x-2'),
        variant: "sm",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: slippageError === SlippageError.InvalidInput ? i18n._(
          /*i18n*/
          i18n._("Enter a valid slippage percentage")) : slippageError === SlippageError.RiskyLow ? i18n._(
          /*i18n*/
          i18n._("Your transaction may fail")) : i18n._(
          /*i18n*/
          i18n._("Your transaction may be frontrun"))
        })
      }) : null]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid gap-2",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "sm",
          className: "text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Transaction deadline"))
        }), /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
          text: i18n._(
          /*i18n*/
          i18n._("Your transaction will revert if it is pending for more than this long."))
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-2 rounded bg-dark-800 min-w-[82px] max-w-[102px]",
          style: {
            maxWidth: '40px',
            marginRight: '8px'
          },
          tabIndex: -1,
          children: /*#__PURE__*/jsx_runtime_.jsx("input", {
            className: (0,functions/* classNames */.AK)(deadlineError ? 'text-red' : '', 'bg-transparent placeholder-low-emphesis'),
            placeholder: (constants/* DEFAULT_DEADLINE_FROM_NOW */.PY / 60).toString(),
            value: deadlineInput.length > 0 ? deadlineInput : deadline === constants/* DEFAULT_DEADLINE_FROM_NOW */.PY ? '' : (deadline / 60).toString(),
            onChange: e => parseCustomDeadline(e.target.value),
            onBlur: () => {
              setDeadlineInput('');
              setDeadlineError(false);
            },
            color: deadlineError ? 'red' : ''
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "sm",
          children: i18n._(
          /*i18n*/
          i18n._("minutes"))
        })]
      })]
    })]
  });
}
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var src_hooks = __webpack_require__(9202);
// EXTERNAL MODULE: ./src/hooks/useOnClickOutside.tsx
var useOnClickOutside = __webpack_require__(525);
;// CONCATENATED MODULE: ./src/components/Settings/index.tsx

















function SettingsTab({
  placeholderSlippage
}) {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    chainId
  } = (0,src_hooks/* useActiveWeb3React */.aQ)();
  const node = (0,external_react_.useRef)(null);
  const open = (0,application_hooks/* useModalOpen */.oL)(actions/* ApplicationModal.SETTINGS */.Lk.SETTINGS);
  const toggle = (0,application_hooks/* useToggleSettingsMenu */.nU)();
  const [expertMode, toggleExpertMode] = (0,hooks/* useExpertModeManager */.DG)();
  const [singleHopOnly, setSingleHopOnly] = (0,hooks/* useUserSingleHopOnly */.RO)(); // show confirmation view before turning on

  const {
    0: showConfirmation,
    1: setShowConfirmation
  } = (0,external_react_.useState)(false);
  (0,useOnClickOutside/* useOnClickOutside */.t)(node, open ? toggle : undefined);
  const [ttl, setTtl] = (0,hooks/* useUserTransactionTTL */.A6)();
  const [userUseArcher, setUserUseArcher] = (0,hooks/* useUserArcherUseRelay */.AC)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "relative flex",
    ref: node,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex items-center justify-center w-8 h-8 rounded cursor-pointer",
      onClick: toggle,
      id: "open-settings-dialog-button",
      children: /*#__PURE__*/jsx_runtime_.jsx(esm/* AdjustmentsIcon */.XgF, {
        className: "w-[26px] h-[26px] transform rotate-90"
      })
    }), open && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute top-14 right-0 z-50 -mr-2.5 min-w-20 md:m-w-22 md:-mr-5 bg-dark-900 border-2 border-dark-800 rounded w-80 shadow-lg",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 space-y-4",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          weight: 700,
          className: "text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Transaction Settings"))
        }), /*#__PURE__*/jsx_runtime_.jsx(TransactionSettings, {
          placeholderSlippage: placeholderSlippage
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          className: "text-high-emphesis",
          weight: 700,
          children: i18n._(
          /*i18n*/
          i18n._("Interface Settings"))
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              variant: "sm",
              className: "text-primary",
              children: i18n._(
              /*i18n*/
              i18n._("Toggle Expert Mode"))
            }), /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
              text: i18n._(
              /*i18n*/
              i18n._("Bypasses confirmation modals and allows high slippage trades. Use at your own risk."))
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(Toggle, {
            id: "toggle-expert-mode-button",
            isActive: expertMode,
            toggle: expertMode ? () => {
              toggleExpertMode();
              setShowConfirmation(false);
            } : () => {
              toggle();
              setShowConfirmation(true);
            }
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex items-center justify-between",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              variant: "sm",
              className: "text-primary",
              children: i18n._(
              /*i18n*/
              i18n._("Disable Multihops"))
            }), /*#__PURE__*/jsx_runtime_.jsx(QuestionHelper/* default */.Z, {
              text: i18n._(
              /*i18n*/
              i18n._("Restricts swaps to direct pairs only."))
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(Toggle, {
            id: "toggle-disable-multihop-button",
            isActive: singleHopOnly,
            toggle: () => singleHopOnly ? setSingleHopOnly(false) : setSingleHopOnly(true)
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(Modal/* default */.Z, {
      isOpen: showConfirmation,
      onDismiss: () => setShowConfirmation(false),
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "space-y-4",
        children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
          title: i18n._(
          /*i18n*/
          i18n._("Are you sure?")),
          onClose: () => setShowConfirmation(false)
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "lg",
          children: i18n._(
          /*i18n*/
          i18n._("Expert mode turns off the confirm transaction prompt and allows high slippage trades\nthat often result in bad rates and lost funds."))
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "sm",
          className: "font-medium",
          children: i18n._(
          /*i18n*/
          i18n._("ONLY USE THIS MODE IF YOU KNOW WHAT YOU ARE DOING."))
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
          color: "red",
          size: "lg",
          onClick: () => {
            // if (window.prompt(i18n._(t`Please type the word "confirm" to enable expert mode.`)) === 'confirm') {
            //   toggleExpertMode()
            //   setShowConfirmation(false)
            // }
            toggleExpertMode();
            setShowConfirmation(false);
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
            variant: "lg",
            id: "confirm-expert-mode",
            children: i18n._(
            /*i18n*/
            i18n._("Turn On Expert Mode"))
          })
        })]
      })
    })]
  });
}
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/components/Badge.tsx
var Badge = __webpack_require__(5696);
// EXTERNAL MODULE: ./src/hooks/useLimitOrders.ts
var useLimitOrders = __webpack_require__(4829);
;// CONCATENATED MODULE: ./src/features/limit-order/MyOrders.tsx









const MyOrders = () => {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    pending
  } = (0,useLimitOrders/* default */.Z)();
  return /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
    href: "/open-order",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      className: "text-secondary hover:text-high-emphesis",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "md:flex hidden gap-3 items-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: i18n._(
          /*i18n*/
          i18n._("My Orders"))
        }), /*#__PURE__*/jsx_runtime_.jsx(Badge/* default */.ZP, {
          color: "blue",
          children: pending.totalOrders
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex md:hidden text-primary",
        children: /*#__PURE__*/jsx_runtime_.jsx(esm/* ClipboardListIcon */.zTD, {
          className: "w-[26px] h-[26px]"
        })
      })]
    })
  });
};

/* harmony default export */ const limit_order_MyOrders = (MyOrders);
;// CONCATENATED MODULE: ./src/components/ExchangeHeader.tsx













const getQuery = (input, output) => {
  if (!input && !output) return;

  if (input && !output) {
    return {
      inputCurrency: input.address || 'ETH'
    };
  } else if (input && output) {
    return {
      inputCurrency: input.address,
      outputCurrency: output.address
    };
  }
};

const ExchangeHeader = ({
  input,
  output,
  allowedSlippage
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    chainId
  } = (0,src_hooks/* useActiveWeb3React */.aQ)();
  const router = (0,router_.useRouter)();
  const {
    0: animateWallet,
    1: setAnimateWallet
  } = (0,external_react_.useState)(false);
  const isRemove = router.asPath.startsWith('/remove');
  const isLimitOrder = router.asPath.startsWith('/limit-order');
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex items-center justify-between mb-4 space-x-3",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid grid-cols-2 rounded p-3px bg-dark-800 h-[46px]",
      children: [/*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
        activeClassName: "font-bold border rounded text-high-emphesis border-dark-800 bg-gradient-to-r from-opaque-green to-white-green hover:from-middle-green hover:to-white",
        href: {
          pathname: '/swap',
          query: getQuery(input, output)
        },
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "flex items-center justify-center px-4 text-base font-medium text-center rounded-md text-secondary hover:text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Swap"))
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
        activeClassName: "font-bold border rounded text-high-emphesis border-dark-800 bg-gradient-to-r from-opaque-green to-white-green hover:from-middle-green hover:to-white",
        href: `/${!isRemove ? 'add' : 'remove'}${input ? `/${(0,functions/* currencyId */.Hh)(input)}` : ''}${output ? `/${(0,functions/* currencyId */.Hh)(output)}` : ''}`,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "flex items-center justify-center px-4 text-base font-medium text-center rounded-md text-secondary hover:text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Liquidity"))
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex items-center",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-flow-col gap-1",
        children: [isLimitOrder && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "items-center h-full w-full cursor-pointer hover:bg-dark-800 rounded px-3 py-1.5",
          children: /*#__PURE__*/jsx_runtime_.jsx(limit_order_MyOrders, {})
        }), chainId === sdk_.ChainId.MAINNET && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "items-center hidden w-full h-full px-3 space-x-3 rounded cursor-pointer text-green text-opacity-80 hover:text-opacity-100 md:flex hover:bg-dark-800",
          children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
            width: "18",
            height: "20",
            viewBox: "0 0 18 20",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/jsx_runtime_.jsx("path", {
              d: "M13.5215 0.618164L12.6818 1.57302L15.933 4.37393V13.2435C15.9114 13.6891 15.5239 14.0498 15.0502 14.0286C14.6196 14.0074 14.2751 13.6679 14.2536 13.2435V7.28093C14.2536 6.21998 13.3923 5.37122 12.3158 5.37122H11.8421V2.67641C11.8421 1.61546 10.9808 0.766697 9.90428 0.766697H1.93779C0.861242 0.766697 0 1.61546 0 2.67641V18.4421C0 18.9089 0.387559 19.2909 0.861242 19.2909H10.9808C11.4545 19.2909 11.8421 18.9089 11.8421 18.4421V6.64436H12.3158C12.6818 6.64436 12.9617 6.92021 12.9617 7.28093V13.2435C13.0048 14.4105 13.9737 15.3017 15.1579 15.2805C16.2775 15.2381 17.1818 14.3469 17.2248 13.2435V3.80102L13.5215 0.618164ZM9.66744 8.89358H2.17464V3.10079H9.66744V8.89358Z",
              fill: "#7CFF6B"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "hidden md:block text-baseline",
            children: /*#__PURE__*/jsx_runtime_.jsx(components_Gas, {})
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "relative flex items-center w-full h-full rounded hover:bg-dark-800",
          children: /*#__PURE__*/jsx_runtime_.jsx(SettingsTab, {
            placeholderSlippage: allowedSlippage
          })
        })]
      })
    })]
  });
};

/* harmony default export */ const components_ExchangeHeader = (ExchangeHeader);

/***/ }),

/***/ 1945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UnsupportedCurrencyFooter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Row__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7745);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Column__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1898);
/* harmony import */ var _components_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7603);
/* harmony import */ var _components_CloseIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9885);
/* harmony import */ var _components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7271);
/* harmony import */ var _components_ExternalLink__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3106);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1441);
/* harmony import */ var _functions_explorer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3302);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8269);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6269);














const DetailsFooter = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "UnsupportedCurrencyFooter__DetailsFooter",
  componentId: "sc-16au0zd-0"
})(["padding-top:calc(16px + 2rem);padding-bottom:20px;margin-top:-2rem;width:100%;border-bottom-left-radius:20px;border-bottom-right-radius:20px;z-index:-1;transform:", ";transition:transform 300ms ease-in-out;text-align:center;"], ({
  show
}) => show ? 'translateY(0%)' : 'translateY(-100%)');
const AddressText = styled_components__WEBPACK_IMPORTED_MODULE_10___default().div.withConfig({
  displayName: "UnsupportedCurrencyFooter__AddressText",
  componentId: "sc-16au0zd-1"
})(["font-size:12px;", ""], ({
  theme
}) => theme.mediaWidth.upToSmall`
    font-size: 10px;
`);
function UnsupportedCurrencyFooter({
  show,
  currencies
}) {
  const {
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_11__/* .useActiveWeb3React */ .a)();
  const {
    0: showDetails,
    1: setShowDetails
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const tokens = chainId && currencies ? currencies.map(currency => {
    return currency === null || currency === void 0 ? void 0 : currency.wrapped;
  }) : [];
  const unsupportedTokens = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_12__/* .useUnsupportedTokens */ .l6)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(DetailsFooter, {
    show: show,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
      isOpen: showDetails,
      onDismiss: () => setShowDetails(false),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
          padding: '2rem'
        },
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
          gap: "lg",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_1__/* .RowBetween */ .m0, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              children: "Unsupported Assets"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CloseIcon__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
              onClick: () => setShowDetails(false)
            })]
          }), tokens.map(token => {
            var _token$address;

            return token && unsupportedTokens && Object.keys(unsupportedTokens).includes(token.address) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: "border border-dark-700",
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
                gap: "10px",
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Row__WEBPACK_IMPORTED_MODULE_1__/* .AutoRow */ .BA, {
                  gap: "5px",
                  align: "center",
                  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CurrencyLogo__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
                    currency: token,
                    size: '24px'
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "font-medium",
                    children: token.symbol
                  })]
                }), chainId && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ExternalLink__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
                  href: (0,_functions_explorer__WEBPACK_IMPORTED_MODULE_9__/* .getExplorerLink */ .E)(chainId, token.address, 'address'),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressText, {
                    children: token.address
                  })
                })]
              })
            }, (_token$address = token.address) === null || _token$address === void 0 ? void 0 : _token$address.concat('not-supported'));
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Column__WEBPACK_IMPORTED_MODULE_3__/* .AutoColumn */ .Tz, {
            gap: "lg",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: "font-medium",
              children: "Some assets are not available through this interface because they may not work well with our smart contract or we are unable to allow trading for legal reasons."
            })
          })]
        })
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Button__WEBPACK_IMPORTED_MODULE_4__/* .default */ .ZP, {
      variant: "empty",
      style: {
        padding: '0px'
      },
      onClick: () => setShowDetails(true),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Read more about unsupported assets"
      })
    })]
  });
}

/***/ }),

/***/ 9539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ useIsSwapUnsupported)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Tokens__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6269);


/**
 * Returns true if the input currency or output currency cannot be traded in the interface
 * @param currencyIn the input currency to check
 * @param currencyOut the output currency to check
 */

function useIsSwapUnsupported(currencyIn, currencyOut) {
  const unsupportedTokens = (0,_Tokens__WEBPACK_IMPORTED_MODULE_1__/* .useUnsupportedTokens */ .l6)();
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
    // if unsupported list loaded & either token on list, mark as unsupported
    return Boolean(unsupportedTokens && ((currencyIn === null || currencyIn === void 0 ? void 0 : currencyIn.isToken) && unsupportedTokens[currencyIn.address] || (currencyOut === null || currencyOut === void 0 ? void 0 : currencyOut.isToken) && unsupportedTokens[currencyOut.address]));
  }, [currencyIn, currencyOut, unsupportedTokens]);
}

/***/ }),

/***/ 4829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9202);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7749);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(swr__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var limitorderv2_sdk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(397);
/* harmony import */ var limitorderv2_sdk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(limitorderv2_sdk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4879);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6269);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const denominator = (decimals = 18) => _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.exponentiate(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(10), _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.JSBI.BigInt(decimals));

const viewUrl = `${limitorderv2_sdk__WEBPACK_IMPORTED_MODULE_2__.LAMBDA_URL}/orders/view`;

const viewFetcher = (url, account, chainId, pendingPage, page) => {
  return fetch(url, {
    method: 'POST',
    body: JSON.stringify({
      address: account,
      chainId,
      page,
      pendingPage
    })
  }).then(r => r.json()).then(j => j.data);
};

const useLimitOrders = () => {
  const {
    account,
    chainId
  } = (0,___WEBPACK_IMPORTED_MODULE_0__/* .useActiveWeb3React */ .aQ)();
  const limitOrderContract = (0,___WEBPACK_IMPORTED_MODULE_0__/* .useLimitOrderContract */ .JY)();
  const tokens = (0,_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useAllTokens */ .e_)();
  const {
    0: state,
    1: setState
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
    pending: {
      page: 1,
      maxPages: null,
      data: [],
      loading: true,
      totalOrders: 0
    },
    completed: {
      page: 1,
      maxPages: null,
      data: [],
      loading: true,
      totalOrders: 0
    }
  });
  const shouldFetch = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => viewUrl && account && chainId ? [viewUrl, account, chainId, state.pending.page, state.completed.page] : null, [account, chainId, state.completed.page, state.pending.page]);
  const {
    data: ordersData,
    mutate
  } = swr__WEBPACK_IMPORTED_MODULE_1___default()(shouldFetch, viewFetcher);
  const setPendingPage = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(page => {
    setState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
      pending: _objectSpread(_objectSpread({}, prevState.pending), {}, {
        page,
        loading: true
      })
    }));
  }, []);
  const setCompletedPage = (0,react__WEBPACK_IMPORTED_MODULE_4__.useCallback)(page => {
    setState(prevState => _objectSpread(_objectSpread({}, prevState), {}, {
      completed: _objectSpread(_objectSpread({}, prevState.completed), {}, {
        page,
        loading: true
      })
    }));
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    if (!account || !chainId || !ordersData || !ordersData.pendingOrders || !ordersData.otherOrders || !Array.isArray(ordersData.pendingOrders.orders) || !Array.isArray(ordersData.otherOrders.orders)) return;

    const transform = async order => {
      const limitOrder = limitorderv2_sdk__WEBPACK_IMPORTED_MODULE_2__.LimitOrder.getLimitOrder(_objectSpread(_objectSpread({}, order), {}, {
        chainId: +order.chainId,
        tokenInDecimals: +order.tokenInDecimals,
        tokenOutDecimals: +order.tokenOutDecimals
      }));
      const tokenIn = limitOrder.amountIn.currency;
      const tokenOut = limitOrder.amountOut.currency;
      const openOrder = {
        tokenIn: tokens[tokenIn.address] || new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.Token(chainId, tokenIn.address.toLowerCase(), tokenIn.decimals, tokenIn.symbol),
        tokenOut: tokens[tokenOut.address] || new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.Token(chainId, tokenOut.address.toLowerCase(), tokenOut.decimals, tokenOut.symbol),
        limitOrder,
        filledPercent: order.filledAmount ? order.filledAmount.mul(ethers__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from('100')).div(ethers__WEBPACK_IMPORTED_MODULE_3__.BigNumber.from(order.amountIn)).toString() : '0',
        status: order.status,
        rate: new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.Percent(limitOrder.amountOut.quotient, denominator(tokenOut.decimals)).divide(new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_5__.Percent(limitOrder.amountIn.quotient, denominator(tokenIn.decimals))).divide(denominator(2)).toSignificant(6)
      };
      return openOrder;
    };

    (async () => {
      const openOrders = await Promise.all(ordersData.pendingOrders.orders.map(el => transform(el)));
      const completedOrders = await Promise.all(ordersData.otherOrders.orders.map(el => transform(el)));
      setState(prevState => ({
        pending: _objectSpread(_objectSpread({}, prevState.pending), {}, {
          data: openOrders,
          maxPages: ordersData.pendingOrders.pendingOrderMaxPage,
          loading: false,
          totalOrders: ordersData.pendingOrders.totalPendingOrders
        }),
        completed: _objectSpread(_objectSpread({}, prevState.completed), {}, {
          data: completedOrders,
          maxPages: ordersData.otherOrders.maxPage,
          loading: false,
          totalOrders: ordersData.otherOrders.totalOrders
        })
      }));
    })(); // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [account, chainId, ordersData, limitOrderContract, setPendingPage, setCompletedPage]);
  return (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => _objectSpread(_objectSpread({}, state), {}, {
    pending: _objectSpread(_objectSpread({}, state.pending), {}, {
      setPage: setPendingPage
    }),
    completed: _objectSpread(_objectSpread({}, state.completed), {}, {
      setPage: setCompletedPage
    }),
    mutate
  }), [mutate, setCompletedPage, setPendingPage, state]);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useLimitOrders);

/***/ }),

/***/ 4656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ useTransactionDeadline)
});

// EXTERNAL MODULE: ./src/state/hooks.ts
var hooks = __webpack_require__(9268);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 33 modules
var useContract = __webpack_require__(1263);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var multicall_hooks = __webpack_require__(879);
;// CONCATENATED MODULE: ./src/hooks/useCurrentBlockTimestamp.ts

 // gets the current timestamp from the blockchain

function useCurrentBlockTimestamp() {
  var _useSingleCallResult, _useSingleCallResult$;

  const multicall = (0,useContract/* useMulticall2Contract */.Fe)();
  return (_useSingleCallResult = (0,multicall_hooks/* useSingleCallResult */.Wk)(multicall, 'getCurrentBlockTimestamp')) === null || _useSingleCallResult === void 0 ? void 0 : (_useSingleCallResult$ = _useSingleCallResult.result) === null || _useSingleCallResult$ === void 0 ? void 0 : _useSingleCallResult$[0];
}
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/hooks/useTransactionDeadline.ts


 // combines the block timestamp with the user setting to give the deadline that should be used for any submitted transaction

function useTransactionDeadline() {
  const ttl = (0,hooks/* useAppSelector */.C)(state => state.user.userDeadline);
  const blockTimestamp = useCurrentBlockTimestamp();
  console.log({
    ttl,
    blockTimestamp
  });
  return (0,external_react_.useMemo)(() => {
    if (blockTimestamp && ttl) return blockTimestamp.add(ttl);
    return undefined;
  }, [blockTimestamp, ttl]);
}

/***/ }),

/***/ 6820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "pM": () => (/* binding */ ConfirmationModalContent),
  "ht": () => (/* binding */ TransactionErrorContent),
  "ZP": () => (/* binding */ modals_TransactionConfirmationModal)
});

// UNUSED EXPORTS: ConfirmationPendingContent, TransactionSubmittedContent

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react-feather"
var external_react_feather_ = __webpack_require__(9337);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/Button/index.tsx
var Button = __webpack_require__(7603);
// EXTERNAL MODULE: ./src/components/CloseIcon.tsx
var CloseIcon = __webpack_require__(9885);
// EXTERNAL MODULE: ./src/components/ExternalLink/index.tsx
var ExternalLink = __webpack_require__(3106);
// EXTERNAL MODULE: ./src/components/Image/index.tsx
var Image = __webpack_require__(5579);
// EXTERNAL MODULE: external "lottie-react"
var external_lottie_react_ = __webpack_require__(2409);
var external_lottie_react_default = /*#__PURE__*/__webpack_require__.n(external_lottie_react_);
// EXTERNAL MODULE: ./src/components/Modal/index.tsx
var Modal = __webpack_require__(1441);
// EXTERNAL MODULE: ./src/components/ModalHeader/index.tsx
var ModalHeader = __webpack_require__(7144);
// EXTERNAL MODULE: ./src/components/Row/index.tsx
var Row = __webpack_require__(7745);
// EXTERNAL MODULE: ./src/functions/explorer.ts
var explorer = __webpack_require__(3302);
;// CONCATENATED MODULE: ./src/animation/loading-rolling-circle.json
const loading_rolling_circle_namespaceObject = JSON.parse('{"v":"5.6.10","fr":24,"ip":0,"op":72,"w":500,"h":500,"nm":"339-loader-10","ddd":0,"assets":[{"id":"comp_0","layers":[]}],"layers":[{"ddd":0,"ind":1,"ty":0,"nm":"Watermark","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2},"a":{"a":0,"k":[250,250,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"tm":{"a":0,"k":0.292,"ix":2},"w":500,"h":500,"ip":0,"op":500,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":3,"nm":"Color  & Stroke Change","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ef":[{"ty":5,"nm":"Primary","np":3,"mn":"ADBE Color Control","ix":1,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0.886,0.886,0.886],"ix":1}}]},{"ty":5,"nm":"Secondary","np":3,"mn":"ADBE Color Control","ix":2,"en":1,"ef":[{"ty":2,"nm":"Color","mn":"ADBE Color Control-0001","ix":1,"v":{"a":0,"k":[0,0.714,0.945],"ix":1}}]},{"ty":5,"nm":"Stroke","np":3,"mn":"ADBE Slider Control","ix":3,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":112,"ix":1}}]},{"ty":5,"nm":"Scale","np":3,"mn":"ADBE Slider Control","ix":4,"en":1,"ef":[{"ty":0,"nm":"Slider","mn":"ADBE Slider Control-0001","ix":1,"v":{"a":0,"k":100,"ix":1}}]},{"ty":5,"nm":"Axis","np":3,"mn":"ADBE Point Control","ix":5,"en":1,"ef":[{"ty":3,"nm":"Point","mn":"ADBE Point Control-0001","ix":1,"v":{"a":0,"k":[250,250],"ix":1}}]}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":3,"nm":"NULL 2","sr":1,"ks":{"o":{"a":0,"k":0,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[250,250,0],"ix":2,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Axis\')(\'Point\');"},"a":{"a":0,"k":[60,60,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6,"x":"var $bm_rt;\\nvar temp;\\ntemp = thisComp.layer(\'Color  & Stroke Change\').effect(\'Scale\')(\'Slider\');\\n$bm_rt = [\\n    temp,\\n    temp\\n];"}},"ao":0,"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":4,"ty":4,"nm":"Shape Layer 3","parent":5,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.562],"y":[0.589]},"o":{"x":[0.195],"y":[0.225]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.8]},"o":{"x":[0.31],"y":[0.311]},"t":18,"s":[185.773]},{"i":{"x":[0.69],"y":[0.686]},"o":{"x":[0.167],"y":[0.198]},"t":36,"s":[359.73]},{"i":{"x":[0.805],"y":[0.774]},"o":{"x":[0.438],"y":[0.415]},"t":54,"s":[533.78]},{"t":72,"s":[720]}],"ix":10},"p":{"a":0,"k":[0,23.125,0],"ix":2},"a":{"a":0,"k":[0,23.125,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[20,20],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,33.125],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":-1,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":5,"ty":4,"nm":"Shape Layer 2","parent":6,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.21],"y":[0.543]},"o":{"x":[0.167],"y":[0.397]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.602]},"o":{"x":[0.79],"y":[0.46]},"t":18,"s":[90]},{"i":{"x":[0.21],"y":[0.539]},"o":{"x":[0.167],"y":[0.398]},"t":36,"s":[180]},{"i":{"x":[0.833],"y":[0.601]},"o":{"x":[0.79],"y":[0.462]},"t":54,"s":[270]},{"t":72,"s":[360]}],"ix":10},"p":{"a":0,"k":[0,0,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[46,46],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Secondary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,23.125],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":-1,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0},{"ddd":0,"ind":6,"ty":4,"nm":"Shape Layer 1","parent":3,"sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.21],"y":[0.543]},"o":{"x":[0.167],"y":[0.397]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.602]},"o":{"x":[0.79],"y":[0.46]},"t":18,"s":[90]},{"i":{"x":[0.21],"y":[0.539]},"o":{"x":[0.167],"y":[0.398]},"t":36,"s":[180]},{"i":{"x":[0.833],"y":[0.601]},"o":{"x":[0.79],"y":[0.462]},"t":54,"s":[270]},{"t":72,"s":[360]}],"ix":10},"p":{"a":0,"k":[60,60,0],"ix":2},"a":{"a":0,"k":[0,0,0],"ix":1},"s":{"a":0,"k":[430,430,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"d":1,"ty":"el","s":{"a":0,"k":[100,100],"ix":2},"p":{"a":0,"k":[0,0],"ix":3},"nm":"Ellipse Path 1","mn":"ADBE Vector Shape - Ellipse","hd":false},{"ty":"st","c":{"a":0,"k":[0.070588235294,0.074509803922,0.192156877705,1],"ix":3,"x":"var $bm_rt;\\n$bm_rt = thisComp.layer(\'Color  & Stroke Change\').effect(\'Primary\')(\'Color\');"},"o":{"a":0,"k":100,"ix":4},"w":{"a":0,"k":4,"ix":5,"x":"var $bm_rt;\\n$bm_rt = $bm_mul(4 / 100, thisComp.layer(\'Color  & Stroke Change\').effect(\'Stroke\')(\'Slider\'));"},"lc":1,"lj":1,"ml":4,"bm":0,"nm":"Stroke 1","mn":"ADBE Vector Graphic - Stroke","hd":false},{"ty":"tr","p":{"a":0,"k":[0,0],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"Transform"}],"nm":"Ellipse 1","np":2,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":120,"st":0,"bm":0}],"markers":[]}');
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/components/CurrencyLogo/index.tsx + 1 modules
var CurrencyLogo = __webpack_require__(7271);
;// CONCATENATED MODULE: ./src/hooks/useAddTokenToMetaMask.ts



function useAddTokenToMetaMask(currencyToAdd) {
  const {
    chainId,
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const token = currencyToAdd === null || currencyToAdd === void 0 ? void 0 : currencyToAdd.wrapped;
  const {
    0: success,
    1: setSuccess
  } = (0,external_react_.useState)();
  const addToken = (0,external_react_.useCallback)(() => {
    if (library && library.provider.isMetaMask && library.provider.request && token) {
      library.provider.request({
        method: 'wallet_watchAsset',
        params: {
          //@ts-ignore // need this for incorrect ethers provider type
          type: 'ERC20',
          options: {
            address: token.address,
            symbol: token.symbol,
            decimals: token.decimals,
            image: (0,CurrencyLogo/* getTokenLogoURL */.a)(token.address, chainId)
          }
        }
      }).then(success => {
        setSuccess(success);
      }).catch(() => setSuccess(false));
    } else {
      setSuccess(false);
    }
  }, [chainId, library, token]);
  return {
    addToken,
    success
  };
}
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
;// CONCATENATED MODULE: ./src/modals/TransactionConfirmationModal/index.tsx

















const ConfirmationPendingContent = ({
  onDismiss,
  pendingText,
  pendingText2
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-end",
      children: /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
        onClick: onDismiss
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-24 pb-4 m-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx((external_lottie_react_default()), {
        animationData: loading_rolling_circle_namespaceObject,
        autoplay: true,
        loop: true
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center gap-3",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xl font-bold text-high-emphesis",
        children: i18n._(
        /*i18n*/
        i18n._("Waiting for Confirmation"))
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-bold",
        children: pendingText
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "font-bold",
        children: pendingText2
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-sm font-bold text-secondary",
        children: i18n._(
        /*i18n*/
        i18n._("Confirm this transaction in your wallet"))
      })]
    })]
  });
};
const TransactionSubmittedContent = ({
  onDismiss,
  chainId,
  hash,
  currencyToAdd
}) => {
  var _library$provider;

  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    library
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  const {
    addToken,
    success
  } = useAddTokenToMetaMask(currencyToAdd);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-end",
      children: /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
        onClick: onDismiss
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-24 pb-4 m-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.ArrowUpCircle, {
        strokeWidth: 0.5,
        size: 90,
        className: "text-blue"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center gap-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-xl font-bold",
        children: i18n._(
        /*i18n*/
        i18n._("Transaction Submitted"))
      }), chainId && hash && /*#__PURE__*/jsx_runtime_.jsx(ExternalLink/* default */.Z, {
        href: (0,explorer/* getExplorerLink */.E)(chainId, hash, 'transaction'),
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "font-bold text-blue",
          children: "View on explorer"
        })
      }), currencyToAdd && (library === null || library === void 0 ? void 0 : (_library$provider = library.provider) === null || _library$provider === void 0 ? void 0 : _library$provider.isMetaMask) && /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        color: "gradient",
        onClick: addToken,
        className: "w-auto mt-4",
        children: !success ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* RowFixed */.DA, {
          className: "mx-auto space-x-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            children: i18n._(
            /*i18n*/
            i18n._("Add {0} to MetaMask", {
              0: currencyToAdd.symbol
            }))
          }), /*#__PURE__*/jsx_runtime_.jsx(Image/* default */.Z, {
            src: "/images/wallets/metamask.png",
            alt: i18n._(
            /*i18n*/
            i18n._("Add {0} to MetaMask", {
              0: currencyToAdd.symbol
            })),
            width: 24,
            height: 24,
            className: "ml-1"
          })]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(Row/* RowFixed */.DA, {
          children: [i18n._(
          /*i18n*/
          i18n._("Added")), " ", currencyToAdd.symbol]
        })
      })]
    })]
  });
};
const ConfirmationModalContent = ({
  title,
  bottomContent,
  onDismiss,
  topContent
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "grid gap-4",
    children: [/*#__PURE__*/jsx_runtime_.jsx(ModalHeader/* default */.Z, {
      title: title,
      onClose: onDismiss
    }), topContent(), bottomContent()]
  });
};
const TransactionErrorContent = ({
  message,
  onDismiss
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "grid gap-6",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-lg font-medium text-high-emphesis",
          children: i18n._(
          /*i18n*/
          i18n._("Error"))
        }), /*#__PURE__*/jsx_runtime_.jsx(CloseIcon/* default */.Z, {
          onClick: onDismiss
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col items-center justify-center gap-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_feather_.AlertTriangle, {
          className: "text-red",
          style: {
            strokeWidth: 1.5
          },
          size: 64
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "font-bold text-red",
          children: message
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.ZP, {
        color: "gradient",
        size: "lg",
        onClick: onDismiss,
        children: "Dismiss"
      })
    })]
  });
};

const TransactionConfirmationModal = ({
  isOpen,
  onDismiss,
  attemptingTxn,
  hash,
  pendingText,
  pendingText2,
  content,
  currencyToAdd
}) => {
  const {
    chainId
  } = (0,useActiveWeb3React/* useActiveWeb3React */.a)();
  if (!chainId) return null; // confirmation screen

  return /*#__PURE__*/jsx_runtime_.jsx(Modal/* default */.Z, {
    isOpen: isOpen,
    onDismiss: onDismiss,
    maxHeight: 90,
    children: attemptingTxn ? /*#__PURE__*/jsx_runtime_.jsx(ConfirmationPendingContent, {
      onDismiss: onDismiss,
      pendingText: pendingText,
      pendingText2: pendingText2
    }) : hash ? /*#__PURE__*/jsx_runtime_.jsx(TransactionSubmittedContent, {
      chainId: chainId,
      hash: hash,
      onDismiss: onDismiss,
      currencyToAdd: currencyToAdd
    }) : content()
  });
};

/* harmony default export */ const modals_TransactionConfirmationModal = (TransactionConfirmationModal);

/***/ })

};
;