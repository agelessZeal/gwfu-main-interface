"use strict";
exports.id = 5892;
exports.ids = [5892];
exports.modules = {

/***/ 4593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ColoredNumber)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);



function ColoredNumber({
  number,
  percent = false
}) {
  if (isNaN(number) || number === Infinity) number = 0;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)(number >= 0 ? 'text-green' : 'text-red', 'font-normal'),
      children: (number >= 0 ? '+' : '-') + (percent ? (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .formatPercent */ .T3)(number).replace('-', '') : (0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .formatNumberScale */ .nH)(number, true).replace('-', ''))
    })
  });
}

/***/ }),

/***/ 2381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PairList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var _components_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5780);
/* harmony import */ var _features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4593);
/* harmony import */ var _components_DoubleLogo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4596);
/* harmony import */ var _hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6269);










function PairListName({
  pair
}) {
  const token0 = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useCurrency */ .U8)(pair.address0);
  const token1 = (0,_hooks_Tokens__WEBPACK_IMPORTED_MODULE_6__/* .useCurrency */ .U8)(pair.address1);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "flex items-center",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DoubleLogo__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
        currency0: token0,
        currency1: token1,
        size: 32
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ml-3 font-bold text-high-emphesis whitespace-nowrap",
        children: [pair.symbol0, "-", pair.symbol1]
      })]
    })
  });
}

const allColumns = [{
  Header: 'Pair',
  accessor: 'pair',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PairListName, {
    pair: props.value
  }),
  align: 'left'
}, {
  Header: 'Liquidity',
  accessor: 'liquidity',
  Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumberScale */ .nH)(props.value, true),
  align: 'right'
}, {
  Header: 'Volume (24h)',
  HideHeader: '(7d)',
  accessor: 'volume1d',
  Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(props.value, true),
  align: 'right'
}, {
  Header: 'Volume (7d)',
  accessor: 'volume1w',
  Cell: props => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(props.value, true),
  align: 'right'
}, {
  Header: 'Fees (24h)',
  HideHeader: '(7d)',
  accessor: row => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(row.volume1d * 0.003, true),
  align: 'right'
}, {
  Header: 'Fees (7d)',
  accessor: row => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(row.volume1w * 0.003, true),
  align: 'right'
}, {
  Header: 'Fees (Yearly)',
  accessor: row => (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .formatPercent */ .T3)(row.volume1w / 7 * 365 / row.liquidity * 100 * 0.03),
  align: 'right'
}];
const gainersColumns = [{
  Header: 'Pair',
  accessor: 'pair',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PairListName, {
    pair: props.value
  }),
  disableSortBy: true,
  align: 'left'
}, {
  Header: '△ Liquidity (24h)',
  accessor: 'liquidityChangeNumber1d',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Liquidity % (24h)',
  accessor: 'liquidityChangePercent1d',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value,
    percent: true
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Liquidity (7d)',
  accessor: 'liquidityChangeNumber1w',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Liquidity % (7d)',
  accessor: 'liquidityChangePercent1w',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value,
    percent: true
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Volume (24h)',
  accessor: 'volumeChangeNumber1d',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Volume % (24h)',
  accessor: 'volumeChangePercent1d',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value,
    percent: true
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Volume (7d)',
  accessor: 'volumeChangeNumber1w',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value
  }),
  align: 'right',
  sortType: 'basic'
}, {
  Header: '△ Volume % (7d)',
  accessor: 'volumeChangePercent1w',
  Cell: props => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_analytics_ColoredNumber__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
    number: props.value,
    percent: true
  }),
  align: 'right',
  sortType: 'basic'
}];
function PairList({
  pairs,
  type
}) {
  const defaultSortBy = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => {
    switch (type) {
      case 'all':
        return {
          id: 'liquidity',
          desc: true
        };

      case 'gainers':
        return {
          id: 'liquidityChangeNumber1d',
          desc: true
        };

      case 'losers':
        return {
          id: 'liquidityChangeNumber1d',
          desc: false
        };
    }
  }, [type]);
  const columns = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(() => {
    switch (type) {
      case 'all':
        return allColumns;

      case 'gainers':
        return gainersColumns;

      case 'losers':
        return gainersColumns;
    }
  }, [type]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: pairs && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Table__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      columns: columns,
      data: pairs,
      defaultSortBy: defaultSortBy
    })
  });
}

/***/ }),

/***/ 7002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PairTabs)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);






function PairTabs({
  tabs
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "border-b border-gray-700",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: "flex -mb-px space-x-4 overflow-x-auto whitespace-nowrap",
        "aria-label": "Tabs",
        children: tabs.map(tab => {
          var _tab$customCurrent;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
              href: tab.href,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                className: (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)(router.asPath === tab.href ? (_tab$customCurrent = tab.customCurrent) !== null && _tab$customCurrent !== void 0 ? _tab$customCurrent : 'bg-gradient-to-r from-blue to-pink text-transparent bg-clip-text' : 'text-primary hover:text-gray-200', 'group flex flex-auto flex-col px-1 font-bold text-lg'),
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                  className: "inline-flex items-center py-2",
                  children: [tab.icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: 'mr-2',
                    style: router.asPath !== tab.href ? {
                      visibility: 'hidden'
                    } : {},
                    children: tab.icon
                  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: tab.name
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                  className: "",
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)(router.asPath === tab.href && 'border-gradient-r-blue-pink-dark-900 border bg-transparent border-transparent', 'w-full')
                  })
                })]
              })
            })
          }, tab.name);
        })
      })
    })
  });
}

/***/ })

};
;