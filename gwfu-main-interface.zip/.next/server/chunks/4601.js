"use strict";
exports.id = 4601;
exports.ids = [4601];
exports.modules = {

/***/ 4601:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Network)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/hooks/index.ts + 2 modules
var hooks = __webpack_require__(9202);
// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/components/Typography/index.tsx
var Typography = __webpack_require__(3130);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(9260);
// EXTERNAL MODULE: ./src/constants/networks.ts
var constants_networks = __webpack_require__(4965);
// EXTERNAL MODULE: ./src/modals/NetworkModal/index.tsx
var NetworkModal = __webpack_require__(8828);
// EXTERNAL MODULE: external "cookie-cutter"
var external_cookie_cutter_ = __webpack_require__(8760);
var external_cookie_cutter_default = /*#__PURE__*/__webpack_require__.n(external_cookie_cutter_);
// EXTERNAL MODULE: external "@lingui/react"
var react_ = __webpack_require__(2339);
// EXTERNAL MODULE: external "@headlessui/react"
var external_headlessui_react_ = __webpack_require__(4025);
;// CONCATENATED MODULE: ./src/components/Modal/HeadlessUIModal.tsx





const HeadlessUIModal = ({
  isOpen,
  onDismiss,
  children
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(external_headlessui_react_.Transition.Root, {
    show: isOpen,
    as: external_react_.Fragment,
    children: /*#__PURE__*/jsx_runtime_.jsx(external_headlessui_react_.Dialog, {
      as: "div",
      static: true,
      className: "fixed z-10 inset-0 overflow-y-auto",
      open: isOpen,
      onClose: onDismiss,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "relative flex items-center justify-center min-h-screen text-center block",
        children: [/*#__PURE__*/jsx_runtime_.jsx(external_headlessui_react_.Transition.Child, {
          as: external_react_.Fragment,
          enter: "ease-out duration-100",
          enterFrom: "opacity-0",
          enterTo: "opacity-40",
          leave: "ease-in duration-100",
          leaveFrom: "opacity-40",
          leaveTo: "opacity-0",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_headlessui_react_.Dialog.Overlay, {
            className: "fixed inset-0 bg-black bg-opacity-40 transition backdrop-filter backdrop-blur-[3px] backdrop-opacity-100",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "fixed inset-0 mb-[20vw] ml-auto bg-pink bg-opacity-40 w-[60vw] rounded-full z-0 filter blur-[400px] rounded-full"
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "fixed inset-0 mt-[20vw] mr-auto bg-blue bg-opacity-40 w-[60vw] rounded-full z-0 filter blur-[400px] rounded-full"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "inline-block align-middle h-screen",
          "aria-hidden": "true",
          children: "\u200B"
        }), /*#__PURE__*/jsx_runtime_.jsx(external_headlessui_react_.Transition.Child, {
          as: external_react_.Fragment,
          enter: "ease-out duration-100",
          enterFrom: "opacity-0",
          enterTo: "opacity-40",
          leave: "ease-in duration-100",
          leaveFrom: "opacity-40",
          leaveTo: "opacity-0",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "inline-block align-bottom rounded-lg text-left overflow-hidden transform  sm:my-8 sm:align-middle max-w-sm md:max-w-3xl sm:w-full p-4 sm:p-6",
            children: children
          })
        })]
      })
    })
  });
};

/* harmony default export */ const Modal_HeadlessUIModal = (HeadlessUIModal);
// EXTERNAL MODULE: ./src/components/NavLink/index.tsx
var NavLink = __webpack_require__(3233);
;// CONCATENATED MODULE: ./src/guards/Network/index.tsx















const Component = ({
  children,
  networks = []
}) => {
  const {
    i18n
  } = (0,react_.useLingui)();
  const {
    chainId,
    library,
    account
  } = (0,hooks/* useActiveWeb3React */.aQ)();

  const link = /*#__PURE__*/jsx_runtime_.jsx(NavLink/* default */.Z, {
    href: "/swap",
    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
      className: "text-blue focus:outline-none",
      children: i18n._(
      /*i18n*/
      i18n._("home page"))
    })
  });

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Modal_HeadlessUIModal, {
      isOpen: !!account && !networks.includes(chainId),
      onDismiss: () => null,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-7 justify-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          variant: "h1",
          className: "max-w-2xl text-white text-center",
          weight: 700,
          children: i18n._(
          /*i18n*/
          i18n._("Roll it back - this feature is not yet supported on {0}.", {
            0: constants_networks/* NETWORK_LABEL */.z[chainId]
          }))
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          className: "text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx(react_.Trans, {
            id: "Either return to the {link}, or change to an available network.",
            values: {
              link
            },
            components: external_react_.Fragment
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
          className: "uppercase text-white text-center text-lg tracking-[.2rem]",
          weight: 700,
          children: i18n._(
          /*i18n*/
          i18n._("Available Networks"))
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `grid gap-5 md:gap-10 md:grid-cols-[${Math.min(6, networks.length)}] grid-cols-[${Math.min(3, networks.length)}]`,
          children: networks.map((key, idx) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
            className: "text-primary hover:text-white flex items-center flex-col gap-2 justify-start",
            onClick: () => {
              const params = NetworkModal/* SUPPORTED_NETWORKS */.b[key];
              external_cookie_cutter_default().set('chainId', key);

              if (key === sdk_.ChainId.MAINNET) {
                library === null || library === void 0 ? void 0 : library.send('wallet_switchEthereumChain', [{
                  chainId: '0x1'
                }, account]);
              } else {
                library === null || library === void 0 ? void 0 : library.send('wallet_addEthereumChain', [params, account]);
              }
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "w-[40px] h-[40px]",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: constants_networks/* NETWORK_ICON */.w[key],
                alt: "Switch Network",
                className: "rounded-md filter drop-shadow-currencyLogo",
                width: "40px",
                height: "40px"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(Typography/* default */.Z, {
              className: "text-sm",
              children: constants_networks/* NETWORK_LABEL */.z[key]
            })]
          }, idx))
        })]
      })
    }), children]
  });
};

const NetworkGuard = networks => {
  return ({
    children
  }) => /*#__PURE__*/jsx_runtime_.jsx(Component, {
    networks: networks,
    children: children
  });
};

/* harmony default export */ const Network = (NetworkGuard);

/***/ })

};
;