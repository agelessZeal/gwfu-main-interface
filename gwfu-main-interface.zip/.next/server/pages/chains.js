"use strict";
(() => {
var exports = {};
exports.id = 7703;
exports.ids = [7703];
exports.modules = {

/***/ 7269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Status),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8129);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3130);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7749);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swr__WEBPACK_IMPORTED_MODULE_4__);







const getChains = (url = 'https://chainid.network/chains.json') => fetch(url).then(res => res.json());

function Status({
  initialData
}) {
  const res = swr__WEBPACK_IMPORTED_MODULE_4___default()('https://chainid.network/chains.json', getChains, {
    initialData
  });
  const {
    data
  } = res;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Container__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
    id: "chains-page",
    className: "py-4 space-y-6 md:py-8 lg:py-12",
    maxWidth: "6xl",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
        children: "Chains | GWFDex"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
        name: "description",
        content: "Chains..."
      }, "description")]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "w-full max-w-6xl mx-auto",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Typography__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        component: "h1",
        variant: "h1",
        className: "w-full mb-4",
        children: "Chains"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid items-start justify-start grid-cols-2 gap-3 mx-auto ",
        children: data.map((chain, key) => {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "h-full p-1 rounded bg-dark-900 text-primary",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pre", {
              className: "h-full p-4 rounded bg-dark-1000",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("code", {
                children: JSON.stringify(chain, null, 2)
              })
            })
          }, key);
        })
      })]
    })]
  });
}
async function getStaticProps() {
  return {
    props: {
      initialData: await getChains()
    }
  };
}

/***/ }),

/***/ 8688:
/***/ ((module) => {

module.exports = require("@binance-chain/bsc-connector");

/***/ }),

/***/ 7398:
/***/ ((module) => {

module.exports = require("@ethersproject/address");

/***/ }),

/***/ 1446:
/***/ ((module) => {

module.exports = require("@ethersproject/bignumber");

/***/ }),

/***/ 6148:
/***/ ((module) => {

module.exports = require("@ethersproject/constants");

/***/ }),

/***/ 4440:
/***/ ((module) => {

module.exports = require("@ethersproject/contracts");

/***/ }),

/***/ 6497:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 685:
/***/ ((module) => {

module.exports = require("@ethersproject/units");

/***/ }),

/***/ 8690:
/***/ ((module) => {

module.exports = require("@keystonehq/keystone-connector");

/***/ }),

/***/ 6766:
/***/ ((module) => {

module.exports = require("@sushiswap/sdk");

/***/ }),

/***/ 5008:
/***/ ((module) => {

module.exports = require("@web3-react/abstract-connector");

/***/ }),

/***/ 1698:
/***/ ((module) => {

module.exports = require("@web3-react/fortmatic-connector");

/***/ }),

/***/ 7290:
/***/ ((module) => {

module.exports = require("@web3-react/injected-connector");

/***/ }),

/***/ 4248:
/***/ ((module) => {

module.exports = require("@web3-react/lattice-connector");

/***/ }),

/***/ 5228:
/***/ ((module) => {

module.exports = require("@web3-react/portis-connector");

/***/ }),

/***/ 3097:
/***/ ((module) => {

module.exports = require("@web3-react/torus-connector");

/***/ }),

/***/ 9650:
/***/ ((module) => {

module.exports = require("@web3-react/walletconnect-connector");

/***/ }),

/***/ 7690:
/***/ ((module) => {

module.exports = require("@web3-react/walletlink-connector");

/***/ }),

/***/ 7663:
/***/ ((module) => {

module.exports = require("ajv");

/***/ }),

/***/ 4588:
/***/ ((module) => {

module.exports = require("cids");

/***/ }),

/***/ 4879:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 1674:
/***/ ((module) => {

module.exports = require("ethers/lib/utils");

/***/ }),

/***/ 1980:
/***/ ((module) => {

module.exports = require("multicodec");

/***/ }),

/***/ 6841:
/***/ ((module) => {

module.exports = require("multihashes");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 3756:
/***/ ((module) => {

module.exports = require("numeral");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7749:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 4050:
/***/ ((module) => {

module.exports = require("tiny-invariant");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [475,7735,8129,3130], () => (__webpack_exec__(7269)));
module.exports = __webpack_exports__;

})();